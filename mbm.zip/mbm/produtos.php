
<?php

session_start();

require_once __DIR__ . '/config/database.php';

require_once __DIR__ . '/config/database.php';

$imagensProdutos = require __DIR__ . '/config/imagens-produtos.php';

// FUNÇÃO DE SEGURANÇA
function e($valor): string {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

// IMAGEM INDIVIDUAL DE CADA PRODUTO
function imagemProduto(array $produto, array $mapa): string {

    $nome = mb_strtolower(
        trim((string)$produto['nome']),
        'UTF-8'
    );

    foreach ($mapa as $termo => $caminho) {

        if (mb_strpos($nome, mb_strtolower($termo, 'UTF-8')) !== false) {
            return $caminho;
        }
    }

    // Caso não encontre no arquivo separado,
    // utiliza a imagem salva no banco de dados.
    return trim((string)($produto['imagem'] ?? ''));
}

// CARRINHO
if (!isset($_SESSION['carrinho']) || !is_array($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

// CATEGORIAS
$mapaCategorias = [

    'proteinas' => ['proteina', 'proteína', 'whey'],

    'veganos' => ['vegano', 'vegan'],

    'vegetarianos' => ['vegetariano'],

    'termogenicos' => ['termogenico', 'termogênico', 'cafeina', 'cafeína'],

    'vitaminas' => ['vitamina', 'multivitaminico', 'multivitamínico'],

    'linha-clinical' => ['clinical', 'testo', 'booster'],

    'aminoacidos' => ['aminoacido', 'aminoácido', 'bcaa'],

    'creatina' => ['creatina'],

    'carboidratos' => ['carboidrato', 'maltodextrina', 'hipercalorico', 'hipercalórico']

];

// FILTROS
$categoria = trim((string)($_GET['categoria'] ?? ''));
$busca = trim((string)($_GET['busca'] ?? ''));

// ADICIONAR AO CARRINHO
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['acao'] ?? '') === 'adicionar'
) {

    $produtoId = filter_input(INPUT_POST, 'produto_id', FILTER_VALIDATE_INT);

    if ($produtoId) {

        $stmt = $pdo->prepare("
            SELECT id, estoque
            FROM produtos
            WHERE id = ? AND ativo = 1
            LIMIT 1
        ");

        $stmt->execute([$produtoId]);

        $produto = $stmt->fetch(PDO::FETCH_ASSOC);

        if (
            $produto &&
            (int)$produto['estoque'] >
            (int)($_SESSION['carrinho'][$produtoId] ?? 0)
        ) {

            $_SESSION['carrinho'][$produtoId] =
                (int)($_SESSION['carrinho'][$produtoId] ?? 0) + 1;
        }
    }

    $parametros = [];

    if ($categoria !== '') {
        $parametros['categoria'] = $categoria;
    }

    if ($busca !== '') {
        $parametros['busca'] = $busca;
    }

    $destino = 'produtos.php';

    if ($parametros) {
        $destino .= '?' . http_build_query($parametros);
    }

    header('Location: ' . $destino);
    exit;
}

// MONTAR CONSULTA
$where = ['ativo = 1'];
$params = [];

if (isset($mapaCategorias[$categoria])) {

    $partes = [];

    foreach ($mapaCategorias[$categoria] as $termo) {

        $partes[] = '(LOWER(categoria) LIKE ? OR LOWER(nome) LIKE ?)';

        $like = '%' . mb_strtolower($termo, 'UTF-8') . '%';

        $params[] = $like;
        $params[] = $like;
    }

    $where[] = '(' . implode(' OR ', $partes) . ')';
}

// PESQUISA
if ($busca !== '') {

    $where[] = "
        (
            LOWER(nome) LIKE ?
            OR LOWER(descricao) LIKE ?
            OR LOWER(categoria) LIKE ?
        )
    ";

    $like = '%' . mb_strtolower($busca, 'UTF-8') . '%';

    array_push($params, $like, $like, $like);
}

// BUSCAR NO BANCO DE DADOS
$sql = "
    SELECT
        id,
        nome,
        descricao,
        preco,
        estoque,
        categoria,
        imagem
    FROM produtos
    WHERE " . implode(' AND ', $where) . "
    ORDER BY id DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);


// Carregar imagens personalizadas dos produtos
$imagensProdutos = require __DIR__ . '/config/imagens-produtos.php';

// Encontrar imagem pelo nome do produto
function imagemDoProduto(array $produto, array $imagens): string
{
    $nome = mb_strtolower(trim($produto['nome']), 'UTF-8');

    foreach ($imagens as $termo => $caminho) {
        if (mb_strpos($nome, $termo) !== false) {
            return $caminho;
        }
    }

    // Caso não encontre uma imagem personalizada,
    // utiliza a imagem cadastrada no banco de dados.
    return trim((string)($produto['imagem'] ?? ''));
}


// QUANTIDADE NO CARRINHO
$quantidadeCarrinho = array_sum(
    array_map('intval', $_SESSION['carrinho'])
);

// TÍTULO
$titulo = isset($mapaCategorias[$categoria])
    ? 'Categoria: ' . ucfirst(str_replace('-', ' ', $categoria))
    : ($busca !== '' ? 'Busca: ' . $busca : 'Todos os produtos');

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?= e($titulo) ?> | MBM Suplementos</title>

<style>

:root {
    --red: #ed101b;
    --red2: #ff3039;
    --bg: #070708;
    --panel: #121214;
    --line: #29292e;
    --muted: #999;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    background: var(--bg);
    color: #fff;
}

a {
    color: inherit;
    text-decoration: none;
}

/* CABEÇALHO */

.header {
    height: 76px;
    background: #060607;
    border-bottom: 1px solid var(--line);
    display: flex;
    align-items: center;
}

.header-inner {
    width: min(1250px, 92%);
    margin: auto;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.logo img {
    width: 145px;
    max-height: 55px;
    object-fit: contain;
}

nav {
    display: flex;
    align-items: center;
    gap: 25px;
    font-size: 13px;
    font-weight: 800;
}

nav a:hover {
    color: var(--red);
}

.cart {
    background: var(--red);
    padding: 11px 15px;
    border-radius: 7px;
}

/* PÁGINA */

.page {
    width: min(1250px, 92%);
    margin: auto;
    padding: 65px 0 90px;
}

.kicker {
    color: var(--red);
    font-size: 11px;
    font-weight: 900;
    letter-spacing: 3px;
}

.heading {
    display: flex;
    justify-content: space-between;
    align-items: end;
    margin: 10px 0 30px;
    gap: 15px;
}

.heading h1 {
    font-size: clamp(30px, 4vw, 42px);
}

.heading p {
    color: var(--muted);
    font-size: 13px;
    margin-top: 8px;
}

.heading a {
    color: var(--red);
    font-size: 12px;
    font-weight: 800;
}

/* GRID */

.grid {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 18px;
}

/* PRODUTOS */

.card {
    background: linear-gradient(145deg, #19191c, #0d0d0f);
    border: 1px solid var(--line);
    border-radius: 12px;
    overflow: hidden;
    transition: .25s;
}

.card:hover {
    border-color: var(--red);
    transform: translateY(-4px);
}

/* IMAGENS */

.photo {
    height: 260px;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 10px;
    background: radial-gradient(ellipse, #29292d, transparent 72%);
}

.photo img {
    width: 100%;
    height: 100%;
    object-fit: contain;
    transition: .3s;
    filter: drop-shadow(0 10px 15px #000);
}

.card:hover .photo img {
    transform: scale(1.04);
}

/* INFORMAÇÕES */

.info {
    padding: 17px;
}

.category {
    font-size: 10px;
    color: var(--red);
    font-weight: 900;
    letter-spacing: 1.5px;
    text-transform: uppercase;
}

.name {
    font-size: 17px;
    font-weight: 900;
    line-height: 1.4;
    margin: 8px 0;
}

.desc {
    font-size: 11px;
    line-height: 1.5;
    color: #888;
    min-height: 34px;
}

.price {
    font-size: 22px;
    font-weight: 900;
    color: var(--red);
    margin: 16px 0;
}

/* ESTOQUE */

.stock {
    color: #999;
    font-size: 10px;
    margin-bottom: 12px;
}

/* BOTÃO */

.buy {
    width: 100%;
    border: 0;
    border-radius: 7px;
    padding: 12px;
    background: var(--red);
    color: #fff;
    font-size: 11px;
    font-weight: 900;
    cursor: pointer;
    transition: .2s;
}

.buy:hover {
    background: var(--red2);
    transform: translateY(-2px);
}

.buy:disabled {
    background: #444;
    cursor: not-allowed;
    transform: none;
}

/* SEM PRODUTOS */

.empty {
    padding: 45px;
    text-align: center;
    border: 1px solid var(--line);
    border-radius: 12px;
    color: #999;
    grid-column: 1 / -1;
}

/* RODAPÉ */

footer {
    text-align: center;
    padding: 30px;
    color: #777;
    border-top: 1px solid var(--line);
    font-size: 12px;
}

footer strong {
    color: var(--red);
}

/* RESPONSIVIDADE */

@media(max-width: 950px) {
    .grid {
        grid-template-columns: repeat(2, 1fr);
    }
}

@media(max-width: 600px) {

    .header {
        height: auto;
        padding: 14px 0;
    }

    .header-inner {
        flex-wrap: wrap;
    }

    .logo img {
        width: 115px;
    }

    nav {
        gap: 15px;
        font-size: 11px;
        flex-wrap: wrap;
    }

    .grid {
        grid-template-columns: 1fr;
    }

    .photo {
        height: 270px;
    }

    .page {
        padding-top: 40px;
    }

    .heading {
        display: block;
    }
}

</style>

</head>

<body>

<header class="header">

    <div class="header-inner">

        <a class="logo" href="loja.php">
            <img src="img/mbm logo sem fundo.png" alt="MBM Suplementos">
        </a>

        <nav>

            <a href="loja.php">Início</a>

            <a href="produtos.php">Produtos</a>

            <a href="index.php">Entrar</a>

            <a class="cart" href="carrinho.php">
                🛒 Carrinho (<?= $quantidadeCarrinho ?>)
            </a>

        </nav>

    </div>

</header>

<main class="page">

    <div class="kicker">
        CONHEÇA NOSSA LINHA
    </div>

    <div class="heading">

        <div>

            <h1><?= e($titulo) ?></h1>

            <p>
                Suplementos para performance, força e evolução.
            </p>

        </div>

        <a href="loja.php">
            ← Voltar ao início
        </a>

    </div>

    <div class="grid">

        <?php if (!$produtos): ?>

            <div class="empty">
                Nenhum produto encontrado nesta categoria.
                Confira os produtos disponíveis na loja.
            </div>

        <?php endif; ?>

        <?php foreach ($produtos as $produto): ?>

            <?php
           $img = imagemDoProduto($produto, $imagensProdutos);
                $semEstoque = (int)$produto['estoque'] <= 0;
            ?>

            <article class="card">

                <div class="photo">

                    <?php if ($img !== ''): ?>

                        <img
                            src="<?= e($img) ?>"
                            alt="<?= e($produto['nome']) ?>"
                            loading="lazy"
                        >

                    <?php else: ?>

                        <span style="font-size:48px">🥤</span>

                    <?php endif; ?>

                </div>

                <div class="info">

                    <div class="category">
                        <?= e($produto['categoria'] ?? 'Suplemento') ?>
                    </div>

                    <div class="name">
                        <?= e($produto['nome']) ?>
                    </div>

                    <p class="desc">
                        <?= e($produto['descricao'] ?? '') ?>
                    </p>

                    <div class="price">
                        R$ <?= number_format(
                            (float)$produto['preco'],
                            2,
                            ',',
                            '.'
                        ) ?>
                    </div>

                    <div class="stock">
                        <?= $semEstoque ? 'Produto indisponível' : 'Disponível em estoque' ?>
                    </div>

                    <form method="post">

                        <input
                            type="hidden"
                            name="acao"
                            value="adicionar"
                        >

                        <input
                            type="hidden"
                            name="produto_id"
                            value="<?= (int)$produto['id'] ?>"
                        >

                        <button
                            class="buy"
                            type="submit"
                            <?= $semEstoque ? 'disabled' : '' ?>
                        >
                            🛒 <?= $semEstoque ? 'SEM ESTOQUE' : 'ADICIONAR AO CARRINHO' ?>
                        </button>

                    </form>

                </div>

            </article>

        <?php endforeach; ?>

    </div>

</main>

<footer>

    <strong>MBM SUPLEMENTOS</strong>

    <p>Performance • Força • Resultado</p>

    <p>© <?= date('Y') ?> MBM Suplementos. Todos os direitos reservados.</p>

</footer>

</body>
</html>
