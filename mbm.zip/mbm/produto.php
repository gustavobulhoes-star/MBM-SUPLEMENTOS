
<?php

session_start();

require_once __DIR__ . '/config/database.php';

// Inicializa o carrinho
if (!isset($_SESSION['carrinho']) || !is_array($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

// Proteção de saída HTML
function e($valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}

// Busca o ID do produto
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    header('Location: produtos.php');
    exit;
}

// Busca produto no banco
$stmt = $pdo->prepare("
    SELECT id, nome, descricao, preco, estoque, categoria, imagem
    FROM produtos
    WHERE id = ?
      AND ativo = 1
    LIMIT 1
");

$stmt->execute([$id]);
$produto = $stmt->fetch(PDO::FETCH_ASSOC);

// Verifica existência
if (!$produto) {
    http_response_code(404);
    exit('Produto não encontrado.');
}

$erro = '';

// Processamento da compra
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    ($_POST['acao'] ?? '') === 'comprar'
) {
    $q = filter_input(INPUT_POST, 'quantidade', FILTER_VALIDATE_INT);
    $q = max(1, min(99, (int) $q));

    $estoque = (int) $produto['estoque'];
    $quantidadeAtual = (int) ($_SESSION['carrinho'][$id] ?? 0);

    if ($estoque <= 0) {
        $erro = 'Produto indisponível no momento.';
    } elseif (($quantidadeAtual + $q) > $estoque) {
        $erro = 'Quantidade maior que o estoque disponível.';
    } else {
        $_SESSION['carrinho'][$id] = $quantidadeAtual + $q;

        header('Location: finalizar.php');
        exit;
    }
}

// Imagem
$imagem = trim((string) ($produto['imagem'] ?? ''));

if ($imagem === '') {
    $imagem = 'img/produto-sem-imagem.jpg';
}

// Preço
$preco = (float) $produto['preco'];
$estoque = (int) $produto['estoque'];

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= e($produto['nome']) ?> | MBM Suplementos</title>

    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        :root {
            --red: #ed252c;
            --red-hover: #ff3b42;
            --bg: #080809;
            --panel: #111113;
            --border: #29292e;
            --text: #ffffff;
            --muted: #999;
            --green: #28c76f;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
        }

        /* CABEÇALHO */

        header {
            height: 78px;
            border-bottom: 1px solid #242428;
            background: #09090a;
            display: flex;
            align-items: center;
        }

        .header-inner {
            width: min(1200px, 92%);
            margin: auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 28px;
            font-weight: 900;
            font-style: italic;
            color: white;
            text-decoration: none;
            letter-spacing: -1px;
        }

        .logo span {
            color: var(--red);
        }

        nav {
            display: flex;
            gap: 28px;
        }

        nav a {
            color: #ddd;
            text-decoration: none;
            font-size: 13px;
            font-weight: 700;
            transition: .2s;
        }

        nav a:hover {
            color: var(--red);
        }

        /* CONTAINER */

        .container {
            width: min(1200px, 92%);
            margin: 40px auto 80px;
        }

        .back {
            display: inline-block;
            color: #aaa;
            text-decoration: none;
            margin-bottom: 25px;
            font-size: 13px;
            transition: .2s;
        }

        .back:hover {
            color: var(--red);
        }

        /* PRODUTO */

        .product-layout {
            display: grid;
            grid-template-columns: 1.05fr .95fr;
            gap: 36px;
            align-items: start;
        }

        /* IMAGEM */

        .gallery {
            min-height: 520px;
            background: radial-gradient(
                circle,
                #252529 0%,
                #111113 65%,
                #0a0a0b 100%
            );
            border: 1px solid var(--border);
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 30px;
            overflow: hidden;
        }

        .gallery img {
            width: 100%;
            height: 460px;
            object-fit: contain;
            transition: transform .4s;
        }

        .gallery img:hover {
            transform: scale(1.04);
        }

        /* DETALHES */

        .details {
            background: var(--panel);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 30px;
        }

        .category {
            color: var(--red);
            font-size: 11px;
            letter-spacing: 2px;
            font-weight: 900;
            text-transform: uppercase;
        }

        h1 {
            font-size: 30px;
            line-height: 1.2;
            margin: 13px 0 15px;
        }

        .description {
            color: #aaa;
            font-size: 14px;
            line-height: 1.7;
            margin-bottom: 22px;
        }

        /* PREÇO */

        .price {
            font-size: 39px;
            font-weight: 900;
            color: var(--red);
            margin: 10px 0;
        }

        .stock {
            color: var(--green);
            font-size: 12px;
            margin: 8px 0 24px;
        }

        .stock.unavailable {
            color: #ff5555;
        }

        /* CAMPOS */

        label {
            display: block;
            color: #aaa;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 1px;
            margin-bottom: 10px;
        }

        .row {
            display: flex;
            gap: 12px;
            align-items: center;
        }

        .quantity {
            width: 100px;
            background: #080809;
            border: 1px solid #39393e;
            border-radius: 8px;
            color: white;
            padding: 14px;
            font-size: 16px;
            outline: none;
        }

        .quantity:focus {
            border-color: var(--red);
        }

        /* BOTÃO COMPRAR */

        .buy {
            flex: 1;
            border: 0;
            border-radius: 8px;
            background: var(--red);
            color: white;
            font-weight: 900;
            padding: 16px;
            cursor: pointer;
            transition: .25s;
        }

        .buy:hover:not(:disabled) {
            background: var(--red-hover);
            transform: translateY(-2px);
        }

        .buy:disabled {
            background: #555;
            cursor: not-allowed;
        }

        /* DIVISÓRIA */

        .divider {
            height: 1px;
            background: #29292d;
            margin: 25px 0;
        }

        /* FRETE */

        .freight-title {
            font-size: 13px;
            color: white;
            margin-bottom: 14px;
        }

        .freight {
            display: grid;
            grid-template-columns: 1fr 115px;
            gap: 10px;
        }

        .cep {
            width: 100%;
            padding: 15px;
            border: 1px solid #39393e;
            border-radius: 8px;
            background: #080809;
            color: white;
            font-size: 15px;
            outline: none;
            transition: .2s;
        }

        .cep:focus {
            border-color: var(--red);
        }

        .cep::placeholder {
            color: #777;
        }

        .calculate {
            border: 1px solid #444;
            border-radius: 8px;
            background: #202024;
            color: white;
            font-weight: 800;
            cursor: pointer;
            transition: .2s;
        }

        .calculate:hover {
            background: var(--red);
            border-color: var(--red);
        }

        .calculate:disabled {
            opacity: .6;
            cursor: wait;
        }

        /* RESULTADO */

        .freight-result {
            display: none;
            margin-top: 15px;
            padding: 16px;
            border: 1px solid #303036;
            border-radius: 10px;
            background: #19191d;
            color: #ddd;
            font-size: 13px;
            line-height: 1.7;
        }

        .freight-result.success {
            border-color: #246c45;
        }

        .freight-result.error {
            border-color: #a52a32;
            color: #ffb5b8;
        }

        .freight-value {
            color: var(--green);
            font-size: 19px;
            font-weight: 900;
        }

        .note {
            font-size: 11px;
            color: #777;
            line-height: 1.6;
            margin-top: 13px;
        }

        .cep-help {
            display: inline-block;
            color: #aaa;
            font-size: 11px;
            margin-top: 9px;
            text-decoration: underline;
        }

        .cep-help:hover {
            color: var(--red);
        }

        /* ERRO DE COMPRA */

        .purchase-error {
            padding: 13px;
            background: #421316;
            border: 1px solid #a52a32;
            border-radius: 8px;
            color: #ffd8da;
            margin-bottom: 17px;
            font-size: 13px;
        }

        /* RESPONSIVIDADE */

        @media (max-width: 800px) {

            .product-layout {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .gallery {
                min-height: 350px;
            }

            .gallery img {
                height: 320px;
            }

            .details {
                padding: 23px;
            }

            h1 {
                font-size: 25px;
            }

            .price {
                font-size: 33px;
            }

            .container {
                margin-top: 25px;
            }
        }

        @media (max-width: 480px) {

            header {
                height: 68px;
            }

            .logo {
                font-size: 23px;
            }

            nav {
                gap: 13px;
            }

            nav a {
                font-size: 11px;
            }

            .gallery {
                min-height: 290px;
                padding: 15px;
            }

            .gallery img {
                height: 260px;
            }

            .freight {
                grid-template-columns: 1fr;
            }

            .calculate {
                padding: 14px;
            }

            .row {
                flex-wrap: wrap;
            }

            .quantity {
                width: 85px;
            }
        }
    </style>
</head>

<body>

    <!-- CABEÇALHO -->

    <header>
        <div class="header-inner">

            <a class="logo" href="index.php">
                MBM<span>.</span>
            </a>

            <nav>
                <a href="index.php">Início</a>
                <a href="produtos.php">Produtos</a>
                <a href="carrinho.php">Carrinho</a>
            </nav>

        </div>
    </header>

    <!-- CONTEÚDO -->

    <main class="container">

        <a class="back" href="produtos.php">
            ← VOLTAR À LOJA
        </a>

        <div class="product-layout">

            <!-- IMAGEM -->

            <div class="gallery">

                <img
                    src="<?= e($imagem) ?>"
                    alt="<?= e($produto['nome']) ?>"
                >

            </div>

            <!-- DETALHES -->

            <section class="details">

                <span class="category">
                    <?= e($produto['categoria'] ?: 'Suplemento') ?>
                </span>

                <h1>
                    <?= e($produto['nome']) ?>
                </h1>

                <p class="description">
                    <?= nl2br(e($produto['descricao'] ?? '')) ?>
                </p>

                <!-- PREÇO -->

                <div class="price">
                    R$ <?= number_format($preco, 2, ',', '.') ?>
                </div>

                <!-- ESTOQUE -->

                <p class="stock <?= $estoque <= 0 ? 'unavailable' : '' ?>">
                    <?= $estoque > 0
                        ? '✓ Em estoque'
                        : 'Produto indisponível'
                    ?>
                </p>

                <!-- ERRO -->

                <?php if ($erro !== ''): ?>

                    <div class="purchase-error">
                        <?= e($erro) ?>
                    </div>

                <?php endif; ?>

                <!-- COMPRA -->

                <form method="post">

                    <input
                        type="hidden"
                        name="acao"
                        value="comprar"
                    >

                    <label for="quantidade">
                        QUANTIDADE
                    </label>

                    <div class="row">

                        <input
                            class="quantity"
                            id="quantidade"
                            name="quantidade"
                            type="number"
                            min="1"
                            max="<?= min(99, $estoque) ?>"
                            value="1"
                            required
                            <?= $estoque <= 0 ? 'disabled' : '' ?>
                        >

                        <button
                            class="buy"
                            type="submit"
                            <?= $estoque <= 0 ? 'disabled' : '' ?>
                        >
                            COMPRAR AGORA
                        </button>

                    </div>

                </form>

                <div class="divider"></div>

                <!-- CALCULAR FRETE -->

                <h3 class="freight-title">
                    CALCULAR FRETE
                </h3>

                <div class="freight">

                    <input
                        class="cep"
                        id="cep"
                        type="text"
                        inputmode="numeric"
                        autocomplete="postal-code"
                        maxlength="9"
                        placeholder="Digite seu CEP"
                        aria-label="CEP para calcular frete"
                    >

                    <button
                        class="calculate"
                        id="calcular"
                        type="button"
                    >
                        CALCULAR
                    </button>

                </div>

                <a
                    class="cep-help"
                    href="https://buscacepinter.correios.com.br/"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    Não sei meu CEP
                </a>

                <!-- RESULTADO -->

                <div
                    class="freight-result"
                    id="resultado-frete"
                    aria-live="polite"
                    role="status"
                ></div>

                <p class="note">
                    O frete estimado segue a regra da loja:
                    R$ 19,90 ou grátis em compras a partir
                    de R$ 199,00.

                    O valor definitivo será confirmado no checkout.
                </p>

            </section>

        </div>

    </main>

    <!-- JAVASCRIPT -->

    <script>
        const campo = document.getElementById('cep');
        const saida = document.getElementById('resultado-frete');
        const botao = document.getElementById('calcular');

        const quantidade = document.getElementById('quantidade');

        const precoProduto = <?= json_encode(
            $preco,
            JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
        ) ?>;

        // Formatação automática do CEP

        campo.addEventListener('input', function () {

            let valor = campo.value
                .replace(/\D/g, '')
                .slice(0, 8);

            if (valor.length > 5) {
                valor = valor.slice(0, 5) + '-' + valor.slice(5);
            }

            campo.value = valor;

            saida.style.display = 'none';
            saida.className = 'freight-result';
        });

        // Também permite calcular apertando Enter

        campo.addEventListener('keydown', function (event) {

            if (event.key === 'Enter') {
                event.preventDefault();
                calcularFrete();
            }

        });

        // Atualiza o resultado quando a quantidade muda

        quantidade.addEventListener('input', function () {
            saida.style.display = 'none';
        });

        // Função de cálculo

        async function calcularFrete() {

            const cep = campo.value.replace(/\D/g, '');

            saida.style.display = 'block';
            saida.className = 'freight-result';

            // Validação

            if (cep.length !== 8) {

                saida.classList.add('error');
                saida.textContent =
                    'Digite um CEP válido com 8 números.';

                campo.focus();
                return;
            }

            botao.disabled = true;
            botao.textContent = 'AGUARDE...';

            saida.textContent = 'Consultando endereço...';

            try {

                // Consulta correta ao ViaCEP

                const resposta = await fetch(
                    `https://viacep.com.br/ws/${cep}/json/`
                );

                if (!resposta.ok) {
                    throw new Error('Falha na consulta.');
                }

                const dados = await resposta.json();

                if (dados.erro) {

                    saida.classList.add('error');

                    saida.textContent =
                        'CEP não encontrado. Confira os números digitados.';

                    return;
                }

                // Quantidade

                const qtd = Math.max(
                    1,
                    Math.min(
                        parseInt(quantidade.value || '1', 10),
                        99
                    )
                );

                // Subtotal

                const subtotal = precoProduto * qtd;

                // Regra de frete da loja

                const valorFrete = subtotal >= 199 ? 0 : 19.90;

                const freteTexto = valorFrete === 0
                    ? 'GRÁTIS'
                    : valorFrete.toLocaleString('pt-BR', {
                        style: 'currency',
                        currency: 'BRL'
                    });

                const total = subtotal + valorFrete;

                // Criação segura do resultado

                saida.replaceChildren();

                const endereco = document.createElement('strong');

                endereco.textContent =
                    'Entrega para ' +
                    [dados.localidade, dados.uf]
                        .filter(Boolean)
                        .join(' - ');

                const linha1 = document.createElement('div');

                linha1.textContent =
                    dados.logradouro
                        ? dados.logradouro + ', ' + dados.bairro
                        : 'CEP: ' + campo.value;

                const linha2 = document.createElement('div');

                linha2.textContent =
                    'Frete estimado: ';

                const valor = document.createElement('span');

                valor.className = 'freight-value';
                valor.textContent = freteTexto;

                linha2.appendChild(valor);

                const linha3 = document.createElement('div');

                linha3.textContent =
                    'Subtotal: ' +
                    subtotal.toLocaleString('pt-BR', {
                        style: 'currency',
                        currency: 'BRL'
                    });

                const linha4 = document.createElement('strong');

                linha4.textContent =
                    'Total estimado: ' +
                    total.toLocaleString('pt-BR', {
                        style: 'currency',
                        currency: 'BRL'
                    });

                saida.append(
                    endereco,
                    linha1,
                    linha2,
                    linha3,
                    linha4
                );

                saida.classList.add('success');

            } catch (erro) {

                saida.classList.add('error');

                saida.textContent =
                    'Não foi possível consultar o CEP. Verifique sua conexão e tente novamente.';

            } finally {

                botao.disabled = false;
                botao.textContent = 'CALCULAR';

            }

        }

        // Botão calcular

        botao.addEventListener('click', calcularFrete);

    </script>

</body>
</html>
