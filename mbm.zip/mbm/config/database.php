<?php

$host = "localhost";
$usuario = "root";
$senha = "Home@spSENAI2025!";
$banco = "mbm_suplementos";
$porta = 3306;

try {

    $pdo = new PDO(
        "mysql:host=$host;port=$porta;dbname=$banco;charset=utf8mb4",
        $usuario,
        $senha
    );

    $pdo->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );

    $pdo->setAttribute(
        PDO::ATTR_DEFAULT_FETCH_MODE,
        PDO::FETCH_ASSOC
    );

} catch (PDOException $e) {

    die("
        <!DOCTYPE html>
        <html lang='pt-BR'>
        <head>
            <meta charset='UTF-8'>
            <title>Erro no Banco</title>
            <style>
                body {
                    font-family: Arial;
                    background: #111;
                    color: white;
                    padding: 40px;
                }

                .erro {
                    max-width: 700px;
                    margin: auto;
                    background: #222;
                    border-left: 5px solid #39ff14;
                    padding: 30px;
                    border-radius: 10px;
                }

                h1 {
                    color: #39ff14;
                }

                code {
                    background: #000;
                    padding: 5px 8px;
                    border-radius: 5px;
                }
            </style>
        </head>

        <body>

            <div class='erro'>

                <h1>Erro ao conectar ao banco</h1>

                <p>
                    Não foi possível conectar ao MySQL.
                </p>

                <p>
                    <strong>Banco:</strong>
                    <code>$banco</code>
                </p>

                <p>
                    <strong>Usuário:</strong>
                    <code>$usuario</code>
                </p>

                <p>
                    <strong>Porta:</strong>
                    <code>$porta</code>
                </p>

                <p>
                    <strong>Erro do MySQL:</strong>
                </p>

                <p style='color:#ff5555;'>
                    " . htmlspecialchars($e->getMessage()) . "
                </p>

                <hr>

                <p>
                    Verifique se o MySQL está ligado no XAMPP.
                </p>

            </div>

        </body>
        </html>
    ");

}