<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function usuario_logado(): bool
{
    return isset($_SESSION['usuario_id']);
}

function exigir_login(): void
{
    if (!usuario_logado()) {
        header('Location: /mbm/login.php');
        exit;
    }
}

function admin_logado(): bool
{
    return isset($_SESSION['admin_id']);
}

function exigir_admin(): void
{
    if (!admin_logado()) {
        header('Location: /mbm/admin/login.php');
        exit;
    }
}