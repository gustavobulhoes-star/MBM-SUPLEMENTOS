<?php

require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

exigir_admin();

$id = isset($_GET['id'])
    ? (int) $_GET['id']
    : 0;

$erro = '';

$produto = [
    'nome' => '',
    'descricao' => '',
    'preco' => '',
    'estoque' => 0,
    'categoria' => 'Outros',
    'imagem' => '',
    'ativo' => 1
];


if ($id > 0) {

    $stmt = $pdo->prepare("
        SELECT *
        FROM produtos
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$id]);

    $produtoEncontrado = $stmt->fetch();

    if (!$produtoEncontrado) {
        die('Produto não encontrado.');
    }

    $produto = $produtoEncontrado;
}


/*
|--------------------------------------------------------------------------
| SALVAR
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = trim($_POST['nome'] ?? '');
    $descricao = trim($_POST['descricao'] ?? '');
    $preco = str_replace(
        ',',
        '.',
        trim($_POST['preco'] ?? '0')
    );
    $estoque = (int) ($_POST['estoque'] ?? 0);
    $categoria = trim($_POST['categoria'] ?? 'Outros');
    $imagem = trim($_POST['imagem'] ?? '');
    $ativo = isset($_POST['ativo']) ? 1 : 0;


    if ($nome === '') {

        $erro = 'Digite o nome do produto.';

    } elseif (!is_numeric($preco) || $preco < 0) {

        $erro = 'Digite um preço válido.';

    } elseif ($estoque < 0) {

        $erro = 'O estoque não pode ser negativo.';

    } else {

        if ($id > 0) {

            $stmt = $pdo->prepare("
                UPDATE produtos
                SET
                    nome = ?,
                    descricao = ?,
                    preco = ?,
                    estoque = ?,
                    categoria = ?,
                    imagem = ?,
                    ativo = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $nome,
                $descricao,
                $preco,
                $estoque,
                $categoria,
                $imagem,
                $ativo,
                $id
            ]);

        } else {

            $stmt = $pdo->prepare("
                INSERT INTO produtos
                (
                    nome,
                    descricao,
                    preco,
                    estoque,
                    categoria,
                    imagem,
                    ativo
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $nome,
                $descricao,
                $preco,
                $estoque,
                $categoria,
                $imagem,
                $ativo
            ]);
        }


        header(
            'Location: /mbm/admin/produtos.php?sucesso=1'
        );

        exit;
    }


    $produto['nome'] = $nome;
    $produto['descricao'] = $descricao;
    $produto['preco'] = $preco;
    $produto['estoque'] = $estoque;
    $produto['categoria'] = $categoria;
    $produto['imagem'] = $imagem;
    $produto['ativo'] = $ativo;
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

<meta charset="UTF-8">

<meta
    name="viewport"
    content="width=device-width, initial-scale=1.0"
>

<title>
    <?= $id > 0 ? 'Editar' : 'Novo' ?>
    Produto - MBM
</title>

<link
    rel="stylesheet"
    href="/mbm/assets/css/style.css"
>

</head>

<body>

<header class="admin-header">

<div class="container admin-header-content">

    <div class="logo">
        MBM <span>ADMIN</span>
    </div>

    <nav>

        <a href="/mbm/admin/index.php">
            Dashboard
        </a>

        <a href="/mbm/admin/produtos.php">
            Produtos
        </a>

        <a href="/mbm/admin/logout.php">
            Sair
        </a>

    </nav>

</div>

</header>


<main class="section">

<div class="container form-container">

    <div class="section-title left">

        <p>
            ESTOQUE
        </p>

        <h1>
            <?= $id > 0 ? 'Editar produto' : 'Novo produto' ?>
        </h1>

    </div>


    <?php if ($erro !== ''): ?>

        <div class="alert error">
            <?= htmlspecialchars($erro) ?>
        </div>

    <?php endif; ?>


    <form
        method="POST"
        class="admin-form"
    >

        <label>
            Nome do produto
        </label>

        <input
            type="text"
            name="nome"
            value="<?= htmlspecialchars($produto['nome']) ?>"
            required
        >


        <label>
            Descrição
        </label>

        <textarea
            name="descricao"
            rows="5"
        ><?= htmlspecialchars($produto['descricao']) ?></textarea>


        <div class="form-row">

            <div>

                <label>
                    Preço
                </label>

                <input
                    type="text"
                    name="preco"
                    value="<?= htmlspecialchars($produto['preco']) ?>"
                    placeholder="129.90"
                    required
                >

            </div>


            <div>

                <label>
                    Estoque
                </label>

                <input
                    type="number"
                    name="estoque"
                    min="0"
                    value="<?= (int) $produto['estoque'] ?>"
                    required
                >

            </div>

        </div>


        <label>
            Categoria
        </label>

        <select name="categoria">

            <option
                value="Whey Protein"
                <?= $produto['categoria'] === 'Whey Protein' ? 'selected' : '' ?>
            >
                Whey Protein
            </option>

            <option
                value="Creatina"
                <?= $produto['categoria'] === 'Creatina' ? 'selected' : '' ?>
            >
                Creatina
            </option>

            <option
                value="Pré-Treino"
                <?= $produto['categoria'] === 'Pré-Treino' ? 'selected' : '' ?>
            >
                Pré-Treino
            </option>

            <option
                value="BCAA"
                <?= $produto['categoria'] === 'BCAA' ? 'selected' : '' ?>
            >
                BCAA
            </option>

            <option
                value="Vitaminas"
                <?= $produto['categoria'] === 'Vitaminas' ? 'selected' : '' ?>
            >
                Vitaminas
            </option>

            <option
                value="Outros"
                <?= $produto['categoria'] === 'Outros' ? 'selected' : '' ?>
            >
                Outros
            </option>

        </select>


        <label>
            URL da imagem
        </label>

        <input
            type="text"
            name="imagem"
            value="<?= htmlspecialchars($produto['imagem'] ?? '') ?>"
            placeholder="https://exemplo.com/imagem.jpg"
        >

        <p class="form-help">
            Você pode colocar o endereço de uma imagem.
            Se deixar vazio, o site mostra o logo MBM.
        </p>


        <label class="checkbox">

            <input
                type="checkbox"
                name="ativo"
                <?= $produto['ativo'] ? 'checked' : '' ?>
            >

            Produto ativo na loja

        </label>


        <div class="form-buttons">

            <a
                href="/mbm/admin/produtos.php"
                class="btn btn-secondary"
            >
                CANCELAR
            </a>

            <button
                type="submit"
                class="btn"
            >
                SALVAR PRODUTO
            </button>

        </div>

    </form>

</div>

</main>

</body>
</html>