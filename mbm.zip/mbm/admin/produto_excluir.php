<?php

require_once __DIR__ . '/../config/auth.php';
require_once __DIR__ . '/../config/database.php';

exigir_admin();

$id = isset($_GET['id'])
    ? (int) $_GET['id']
    : 0;

if ($id > 0) {

    try {

        $stmt = $pdo->prepare("
            DELETE FROM produtos
            WHERE id = ?
        ");

        $stmt->execute([$id]);

    } catch (PDOException $e) {

        /*
         * Se o produto já estiver em um pedido,
         * não deixamos apagar para preservar
         * o histórico.
         */

        $stmt = $pdo->prepare("
            UPDATE produtos
            SET ativo = 0
            WHERE id = ?
        ");

        $stmt->execute([$id]);
    }
}

header(
    'Location: /mbm/admin/produtos.php?sucesso=1'
);

exit;