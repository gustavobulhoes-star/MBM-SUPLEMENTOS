<?php

session_start();

require_once __DIR__ . "/../config/database.php";

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nome = trim($_POST["nome"] ?? "");
    $usuario = trim($_POST["usuario"] ?? "");
    $senha = $_POST["senha"] ?? "";

    if ($nome === "" || $usuario === "" || $senha === "") {

        $mensagem = "Preencha todos os campos.";

    } elseif (strlen($senha) < 6) {

        $mensagem = "A senha precisa ter pelo menos 6 caracteres.";

    } else {

        try {

            $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("
                INSERT INTO administradores
                (nome, usuario, senha)
                VALUES (?, ?, ?)
            ");

            $stmt->execute([
                $nome,
                $usuario,
                $senhaHash
            ]);

            $mensagem = "Administrador criado com sucesso!";

        } catch (PDOException $e) {

            if ($e->getCode() == 23000) {
                $mensagem = "Esse usuário já existe.";
            } else {
                $mensagem = "Erro ao criar administrador.";
            }
        }
    }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Criar Administrador | MBM</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            min-height: 100vh;
            background: #080809;
            color: #fff;
            font-family: Arial, Helvetica, sans-serif;

            display: flex;
            align-items: center;
            justify-content: center;
        }

        .box {
            width: 100%;
            max-width: 420px;
            background: #151517;
            padding: 35px;
            border-radius: 14px;
            border: 1px solid #2c2c31;
        }

        h1 {
            margin-bottom: 8px;
        }

        .subtitle {
            color: #888;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin-bottom: 7px;
            font-size: 13px;
        }

        input {
            width: 100%;
            padding: 13px;
            margin-bottom: 18px;

            background: #0c0c0e;
            color: #fff;

            border: 1px solid #333;
            border-radius: 7px;
        }

        button {
            width: 100%;
            padding: 13px;

            border: 0;
            border-radius: 7px;

            background: #e50914;
            color: white;

            font-weight: bold;
            cursor: pointer;
        }

        button:hover {
            background: #ff1822;
        }

        .mensagem {
            margin-bottom: 18px;
            padding: 12px;
            background: #222;
            border-radius: 7px;
            color: #ddd;
        }

    </style>

</head>

<body>

<div class="box">

    <h1>Criar administrador</h1>

    <p class="subtitle">
        MBM Suplementos
    </p>

    <?php if ($mensagem !== ""): ?>

        <div class="mensagem">
            <?= htmlspecialchars($mensagem) ?>
        </div>

    <?php endif; ?>

    <form method="POST">

        <label>Nome</label>

        <input
            type="text"
            name="nome"
            placeholder="Nome do administrador"
            required
        >

        <label>Usuário</label>

        <input
            type="text"
            name="usuario"
            placeholder="Usuário"
            required
        >

        <label>Senha</label>

        <input
            type="password"
            name="senha"
            placeholder="Senha"
            required
        >

        <button type="submit">
            CRIAR ADMINISTRADOR
        </button>

    </form>

</div>

</body>
</html>