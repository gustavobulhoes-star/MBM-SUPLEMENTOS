<?php

require_once __DIR__ . "/verificar-admin.php";

require_once __DIR__ . "/../config/database.php";

$stmt = $pdo->query("
    SELECT *
    FROM produtos
    ORDER BY id DESC
");

$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Painel Administrativo | MBM</title>

    <style>

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background: #080809;
            color: white;
            font-family: Arial, Helvetica, sans-serif;
        }

        header {
            height: 75px;

            background: #111113;

            border-bottom: 1px solid #2c2c31;

            display: flex;
            align-items: center;
            justify-content: space-between;

            padding: 0 5%;
        }

        .logo {
            font-size: 22px;
            font-weight: 900;
        }

        .logo span {
            color: #e50914;
        }

        .admin {
            color: #aaa;
            font-size: 13px;
        }

        .admin strong {
            color: white;
        }

        .logout {
            margin-left: 15px;

            padding: 9px 14px;

            border-radius: 6px;

            background: #e50914;

            color: white;

            text-decoration: none;

            font-size: 12px;
            font-weight: bold;
        }

        main {
            width: 90%;
            max-width: 1250px;

            margin: 40px auto;
        }

        .top {
            display: flex;
            justify-content: space-between;
            align-items: center;

            margin-bottom: 30px;
        }

        h1 {
            font-size: 30px;
        }

        .add {
            background: #e50914;

            color: white;

            padding: 12px 18px;

            border-radius: 7px;

            text-decoration: none;

            font-size: 12px;
            font-weight: 900;
        }

        .table-container {
            overflow-x: auto;

            background: #151517;

            border: 1px solid #2c2c31;

            border-radius: 12px;
        }

        table {
            width: 100%;

            border-collapse: collapse;
        }

        th,
        td {
            padding: 15px;

            text-align: left;

            border-bottom: 1px solid #29292d;
        }

        th {
            color: #888;
            font-size: 11px;
            text-transform: uppercase;
        }

        td {
            font-size: 13px;
        }

        .produto-img {
            width: 60px;
            height: 60px;

            object-fit: contain;

            background: #222;

            border-radius: 7px;
        }

        .excluir {
            color: #ff4b4b;

            text-decoration: none;

            font-weight: bold;
        }

        .excluir:hover {
            color: white;
        }

    </style>

</head>

<body>

<header>

    <div class="logo">
        MBM <span>ADMIN</span>
    </div>

    <div class="admin">

        Olá,
        <strong>
            <?= htmlspecialchars($_SESSION["admin_nome"]) ?>
        </strong>

        <a
            href="logout.php"
            class="logout"
        >
            SAIR
        </a>

    </div>

</header>

<main>

    <div class="top">

        <div>

            <h1>
                Produtos
            </h1>

        </div>

    <a href="produto_adicionar.php" class="btn">
    + ADICIONAR PRODUTO
</a>
    </div>

    <div class="table-container">

        <table>

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Imagem</th>

                    <th>Produto</th>

                    <th>Preço</th>

                    <th>Ação</th>

                </tr>

            </thead>

            <tbody>

                <?php foreach ($produtos as $produto): ?>

                    <tr>

                        <td>
                            <?= (int)$produto["id"] ?>
                        </td>

                        <td>

                            <?php if (!empty($produto["imagem"])): ?>

                                <img
                                    src="../<?= htmlspecialchars($produto["imagem"]) ?>"
                                    class="produto-img"
                                >

                            <?php else: ?>

                                Sem imagem

                            <?php endif; ?>

                        </td>

                        <td>

                            <?= htmlspecialchars($produto["nome"]) ?>

                        </td>

                        <td>

                            R$
                            <?= number_format(
                                (float)$produto["preco"],
                                2,
                                ",",
                                "."
                            ) ?>

                        </td>

                        <td>

                            <a
                                href="produto_excluir.php?id=<?= (int)$produto["id"] ?>"
                                class="excluir"
                                onclick="return confirm('Tem certeza que deseja excluir este produto?');"
                            >
                                Excluir
                            </a>

                        </td>

                    </tr>

                <?php endforeach; ?>

            </tbody>

        </table>

    </div>

</main>

</body>

</html>