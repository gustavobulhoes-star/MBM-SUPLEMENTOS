<?php

session_start();

require_once __DIR__ . "/config/database.php";

$erro = "";

/*
|--------------------------------------------------------------------------
| SE JÁ ESTIVER LOGADO COMO ADMIN
|--------------------------------------------------------------------------
*/

if (isset($_SESSION["admin_id"])) {
    header("Location: admin/index.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| PROCESSAMENTO DO LOGIN
|--------------------------------------------------------------------------
*/

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $usuario = trim($_POST["usuario"] ?? "");
    $senha   = $_POST["senha"] ?? "";

    if ($usuario === "" || $senha === "") {

        $erro = "Preencha usuário e senha.";

    } else {

        /*
        |--------------------------------------------------------------------------
        | 1. PRIMEIRO: VERIFICA ADMINISTRADOR
        |--------------------------------------------------------------------------
        */

        $stmtAdmin = $pdo->prepare("
            SELECT
                id,
                nome,
                usuario,
                senha
            FROM administradores
            WHERE usuario = ?
            LIMIT 1
        ");

        $stmtAdmin->execute([$usuario]);

        $admin = $stmtAdmin->fetch(PDO::FETCH_ASSOC);


        /*
        |--------------------------------------------------------------------------
        | ADMINISTRADOR
        |--------------------------------------------------------------------------
        */

        if (
            $admin &&
            password_verify($senha, $admin["senha"])
        ) {

            session_regenerate_id(true);

            $_SESSION["admin_id"]      = $admin["id"];
            $_SESSION["admin_nome"]    = $admin["nome"];
            $_SESSION["admin_usuario"] = $admin["usuario"];

            header("Location: admin/index.php");
            exit;
        }


        /*
        |--------------------------------------------------------------------------
        | 2. LOGIN DO CLIENTE
        |--------------------------------------------------------------------------
        |
        | IMPORTANTE:
        | A estrutura da tabela de clientes não está disponível no código
        | que você me enviou. Por isso não vou inventar o nome dela.
        |
        | Quando você colocar a consulta do cliente aqui, o fluxo será:
        |
        | Cliente     -> index.php
        | Administrador -> admin/index.php
        |
        |--------------------------------------------------------------------------
        */


        /*
        |--------------------------------------------------------------------------
        | LOGIN NÃO ENCONTRADO
        |--------------------------------------------------------------------------
        */

        $erro = "Usuário ou senha incorretos.";
    }
}

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        MBM Suplementos | Login
    </title>


    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }


        body {

            min-height: 100vh;

            background:
                radial-gradient(
                    circle at 75% 45%,
                    rgba(229, 9, 20, .15),
                    transparent 35%
                ),
                linear-gradient(
                    90deg,
                    #050505 0%,
                    #090909 55%,
                    #170809 100%
                );

            color: #fff;

            font-family:
                Arial,
                Helvetica,
                sans-serif;

            display: flex;

            align-items: center;

            justify-content: center;

            padding: 20px;
        }


        .login {

            width: 100%;

            max-width: 410px;

            background: #151517;

            border:
                1px solid #2c2c31;

            border-top:
                2px solid #e50914;

            border-radius: 12px;

            padding: 30px;

            box-shadow:
                0 25px 70px
                rgba(0, 0, 0, .55);
        }


        .logo {

            text-align: center;

            margin-bottom: 25px;
        }


        .logo h1 {

            font-size: 30px;

            font-weight: 900;

            letter-spacing: -1px;
        }


        .logo span {

            color: #e50914;
        }


        .subtitle {

            margin-top: 8px;

            color: #777;

            font-size: 11px;

            letter-spacing: 2px;

            text-transform: uppercase;
        }


        .erro {

            background:
                rgba(229, 9, 20, .12);

            border:
                1px solid
                rgba(229, 9, 20, .35);

            color: #ff6666;

            padding: 12px;

            border-radius: 7px;

            margin-bottom: 20px;

            font-size: 13px;

            line-height: 1.4;
        }


        label {

            display: block;

            margin-bottom: 7px;

            color: #ddd;

            font-size: 12px;

            font-weight: 800;

            text-transform: uppercase;
        }


        input {

            width: 100%;

            padding: 14px;

            margin-bottom: 18px;

            background: #0c0c0e;

            color: #fff;

            border:
                1px solid #333;

            border-radius: 6px;

            outline: none;

            font-size: 14px;

            transition: .2s;
        }


        input::placeholder {

            color: #555;
        }


        input:focus {

            border-color: #e50914;

            box-shadow:
                0 0 0 2px
                rgba(229, 9, 20, .08);
        }


        button {

            width: 100%;

            padding: 14px;

            border: none;

            border-radius: 6px;

            background: #e50914;

            color: #fff;

            font-size: 12px;

            font-weight: 900;

            cursor: pointer;

            transition: .2s;
        }


        button:hover {

            background: #ff1822;

            transform:
                translateY(-1px);

            box-shadow:
                0 8px 20px
                rgba(229, 9, 20, .20);
        }


        .voltar {

            display: block;

            text-align: center;

            margin-top: 20px;

            color: #777;

            text-decoration: none;

            font-size: 12px;
        }


        .voltar:hover {

            color: #fff;
        }


        .info {

            margin-top: 18px;

            padding-top: 18px;

            border-top:
                1px solid #29292d;

            color: #555;

            font-size: 11px;

            text-align: center;

            line-height: 1.5;
        }

    </style>

</head>


<body>


<div class="login">


    <div class="logo">

        <h1>
            MBM
            <span>SUPLEMENTOS</span>
        </h1>

        <div class="subtitle">

            Performance • Força • Resultado

        </div>

    </div>


    <?php if ($erro !== ""): ?>

        <div class="erro">

            <?= htmlspecialchars($erro) ?>

        </div>

    <?php endif; ?>


    <form method="POST">


        <label for="usuario">
            E-mail ou usuário
        </label>


        <input
            type="text"
            id="usuario"
            name="usuario"
            placeholder="Digite seu e-mail ou usuário"
            autocomplete="username"
            required
        >


        <label for="senha">
            Senha
        </label>


        <input
            type="password"
            id="senha"
            name="senha"
            placeholder="Digite sua senha"
            autocomplete="current-password"
            required
        >


        <button type="submit">

            ENTRAR NA MBM
            &nbsp; →

        </button>


    </form>


    <a
        href="index.php"
        class="voltar"
    >

        ← Voltar para a loja

    </a>


    <div class="info">

        Área de acesso da MBM Suplementos.

    </div>


</div>


</body>

</html>