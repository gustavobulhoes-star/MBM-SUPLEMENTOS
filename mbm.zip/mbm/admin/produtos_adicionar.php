<?php
session_start();

require_once __DIR__ . "/../config/database.php";

if (!isset($_SESSION["admin_id"])) {
    header("Location: ../login.php");
    exit;
}

$erro = "";
$sucesso = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nome = trim($_POST["nome"] ?? "");
    $descricao = trim($_POST["descricao"] ?? "");
    $preco = str_replace(",", ".", trim($_POST["preco"] ?? ""));
    $imagem = "";

    if ($nome === "") {
        $erro = "Digite o nome do produto.";
    } elseif ($preco === "" || !is_numeric($preco)) {
        $erro = "Digite um preço válido.";
    } else {

        $preco = (float) $preco;

        if (isset($_FILES["imagem"]) && $_FILES["imagem"]["error"] !== UPLOAD_ERR_NO_FILE) {

            if ($_FILES["imagem"]["error"] !== UPLOAD_ERR_OK) {
                $erro = "Erro ao enviar a imagem.";
            } else {

                $extensao = strtolower(pathinfo($_FILES["imagem"]["name"], PATHINFO_EXTENSION));
                $permitidas = ["jpg", "jpeg", "png", "webp"];

                if (!in_array($extensao, $permitidas, true)) {
                    $erro = "Use uma imagem JPG, JPEG, PNG ou WEBP.";
                } elseif ($_FILES["imagem"]["size"] > 5 * 1024 * 1024) {
                    $erro = "A imagem deve ter no máximo 5 MB.";
                } else {

                    $pasta = __DIR__ . "/../img/produtos/";

                    if (!is_dir($pasta)) {
                        mkdir($pasta, 0755, true);
                    }

                    $nomeArquivo = "produto_" . uniqid() . "." . $extensao;
                    $destino = $pasta . $nomeArquivo;

                    if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $destino)) {
                        $imagem = "img/produtos/" . $nomeArquivo;
                    } else {
                        $erro = "Não foi possível salvar a imagem.";
                    }
                }
            }
        }

        if ($erro === "") {
            try {
                $stmt = $pdo->prepare("
                    INSERT INTO produtos (nome, descricao, preco, imagem)
                    VALUES (?, ?, ?, ?)
                ");

                $stmt->execute([
                    $nome,
                    $descricao,
                    $preco,
                    $imagem
                ]);

                $sucesso = "Produto adicionado com sucesso!";
                $nome = "";
                $descricao = "";
                $preco = "";

            } catch (PDOException $e) {
                $erro = "Erro ao salvar no banco de dados: " . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Adicionar Produto | MBM Admin</title>

<style>
*{box-sizing:border-box;margin:0;padding:0}
body{
    min-height:100vh;
    background:#080809;
    color:#fff;
    font-family:Arial,Helvetica,sans-serif;
}
header{
    height:80px;
    background:#111113;
    border-bottom:1px solid #29292d;
    display:flex;
    align-items:center;
}
.header{
    width:92%;
    max-width:1100px;
    margin:auto;
    display:flex;
    justify-content:space-between;
    align-items:center;
}
.logo{font-size:22px;font-weight:900}
.logo span{color:#e50914}
.admin{font-size:13px;color:#aaa;display:flex;gap:18px;align-items:center}
.sair{
    background:#e50914;
    color:#fff;
    text-decoration:none;
    padding:10px 17px;
    border-radius:6px;
    font-size:12px;
    font-weight:900;
}
main{width:92%;max-width:850px;margin:45px auto}
.topo{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:25px;
}
h1{font-size:30px}
.voltar{color:#aaa;text-decoration:none;font-size:13px}
.card{
    background:#151517;
    border:1px solid #2c2c31;
    border-radius:12px;
    padding:30px;
}
.campo{margin-bottom:20px}
label{
    display:block;
    margin-bottom:8px;
    font-size:12px;
    font-weight:900;
    color:#ddd;
}
input,textarea{
    width:100%;
    background:#0c0c0e;
    color:#fff;
    border:1px solid #333;
    border-radius:7px;
    padding:14px;
    outline:none;
    font:14px Arial;
}
input:focus,textarea:focus{border-color:#e50914}
textarea{min-height:130px;resize:vertical}
button{
    width:100%;
    border:0;
    border-radius:7px;
    padding:15px;
    background:#e50914;
    color:#fff;
    font-weight:900;
    cursor:pointer;
}
button:hover{background:#ff1822}
.mensagem{
    padding:13px;
    border-radius:7px;
    margin-bottom:20px;
    font-size:13px;
}
.erro{
    background:rgba(229,9,20,.12);
    border:1px solid rgba(229,9,20,.3);
    color:#ff7070;
}
.sucesso{
    background:rgba(0,180,90,.1);
    border:1px solid rgba(0,180,90,.25);
    color:#5ee7a2;
}
.info{font-size:11px;color:#666;margin-top:8px}
</style>
</head>

<body>

<header>
    <div class="header">
        <div class="logo">MBM <span>ADMIN</span></div>

        <div class="admin">
            <span>Olá, <strong><?= htmlspecialchars($_SESSION["admin_nome"] ?? "Administrador") ?></strong></span>
            <a class="sair" href="logout.php">SAIR</a>
        </div>
    </div>
</header>

<main>

    <div class="topo">
        <h1>Adicionar Produto</h1>
        <a class="voltar" href="index.php">← Voltar para produtos</a>
    </div>

    <div class="card">

        <?php if ($erro): ?>
            <div class="mensagem erro">
                <?= htmlspecialchars($erro) ?>
            </div>
        <?php endif; ?>

        <?php if ($sucesso): ?>
            <div class="mensagem sucesso">
                <?= htmlspecialchars($sucesso) ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">

            <div class="campo">
                <label for="nome">NOME DO PRODUTO</label>
                <input
                    type="text"
                    id="nome"
                    name="nome"
                    value="<?= htmlspecialchars($nome ?? "") ?>"
                    placeholder="Ex: Whey Protein 900g"
                    required
                >
            </div>

            <div class="campo">
                <label for="descricao">DESCRIÇÃO</label>
                <textarea
                    id="descricao"
                    name="descricao"
                    placeholder="Descrição do produto..."
                ><?= htmlspecialchars($descricao ?? "") ?></textarea>
            </div>

            <div class="campo">
                <label for="preco">PREÇO</label>
                <input
                    type="text"
                    id="preco"
                    name="preco"
                    value="<?= htmlspecialchars($preco ?? "") ?>"
                    placeholder="129,90"
                    required
                >
            </div>

            <div class="campo">
                <label for="imagem">IMAGEM</label>
                <input
                    type="file"
                    id="imagem"
                    name="imagem"
                    accept=".jpg,.jpeg,.png,.webp"
                >
                <div class="info">JPG, JPEG, PNG ou WEBP — máximo 5 MB.</div>
            </div>

            <button type="submit">+ ADICIONAR PRODUTO</button>

        </form>
    </div>

</main>

</body>
</html>