<?php

require_once __DIR__ . "/verificar-admin.php";

require_once __DIR__ . "/../config/database.php";