<?php
session_start();
require_once __DIR__ . '/config/database.php';

if (!isset($_SESSION['carrinho']) || !is_array($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}
if (empty($_SESSION['csrf_avaliacao'])) {
    $_SESSION['csrf_avaliacao'] = bin2hex(random_bytes(32));
}

function e($valor): string {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

function imagemDoProdutoDetalhe(array $produto, array $imagens): string {
    $nome = mb_strtolower(trim((string)$produto['nome']), 'UTF-8');
    foreach ($imagens as $termo => $caminho) {
        if (mb_strpos($nome, mb_strtolower((string)$termo, 'UTF-8')) !== false) {
            return (string)$caminho;
        }
    }
    return trim((string)($produto['imagem'] ?? ''));
}

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id || $id < 1) {
    http_response_code(404);
    exit('Produto não encontrado.');
}

$stmt = $pdo->prepare(
    'SELECT id, nome, descricao, preco, estoque, categoria, imagem
     FROM produtos WHERE id = ? AND ativo = 1 LIMIT 1'
);
$stmt->execute([$id]);
$produto = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$produto) {
    http_response_code(404);
    exit('Produto não encontrado ou indisponível.');
}

/* Adicionar ao carrinho: mantém o formato usado pela loja atual. */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'adicionar') {
    $quantidade = filter_input(INPUT_POST, 'quantidade', FILTER_VALIDATE_INT);
    $quantidade = max(1, min(20, (int)$quantidade));

    if ((int)$produto['estoque'] < 1) {
        $_SESSION['mensagem_produto'] = 'Este produto está sem estoque no momento.';
    } else {
        $atual = (int)($_SESSION['carrinho'][$id] ?? 0);
        $nova = min((int)$produto['estoque'], $atual + $quantidade);
        $_SESSION['carrinho'][$id] = $nova;
        $_SESSION['mensagem_produto'] = 'Produto adicionado ao carrinho!';
    }

    header('Location: produto.php?id=' . $id);
    exit;
}

/* Cadastro de avaliação. A tabela é criada pelo arquivo SQL entregue junto. */
$erroAvaliacao = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'avaliar') {
    $token = (string)($_POST['csrf'] ?? '');
    $nome = trim((string)($_POST['nome_avaliador'] ?? ''));
    $comentario = trim((string)($_POST['comentario'] ?? ''));
    $nota = filter_input(INPUT_POST, 'nota', FILTER_VALIDATE_INT);

    if (!hash_equals($_SESSION['csrf_avaliacao'], $token)) {
        $erroAvaliacao = 'Sua sessão expirou. Atualize a página e tente novamente.';
    } elseif ($nome === '' || mb_strlen($nome) > 100) {
        $erroAvaliacao = 'Informe seu nome (até 100 caracteres).';
    } elseif (!$nota || $nota < 1 || $nota > 5) {
        $erroAvaliacao = 'Escolha uma nota de 1 a 5 estrelas.';
    } elseif ($comentario === '' || mb_strlen($comentario) < 5 || mb_strlen($comentario) > 1500) {
        $erroAvaliacao = 'Escreva um comentário entre 5 e 1.500 caracteres.';
    } else {
        $ins = $pdo->prepare(
            'INSERT INTO avaliacoes (produto_id, nome, nota, comentario, aprovado)
             VALUES (?, ?, ?, ?, 1)'
        );
        $ins->execute([$id, $nome, $nota, $comentario]);
        $_SESSION['mensagem_produto'] = 'Obrigado! Sua avaliação foi publicada.';
        header('Location: produto.php?id=' . $id . '#avaliacoes');
        exit;
    }
}

$arquivoImagens = __DIR__ . '/config/imagens-produtos.php';
$imagensProdutos = file_exists($arquivoImagens) ? require $arquivoImagens : [];
$imagem = imagemDoProdutoDetalhe($produto, is_array($imagensProdutos) ? $imagensProdutos : []);

$reviewsStmt = $pdo->prepare(
    'SELECT nome, nota, comentario, criado_em
     FROM avaliacoes
     WHERE produto_id = ? AND aprovado = 1
     ORDER BY criado_em DESC
     LIMIT 30'
);
$reviewsStmt->execute([$id]);
$avaliacoes = $reviewsStmt->fetchAll(PDO::FETCH_ASSOC);

$media = 0;
if ($avaliacoes) {
    $media = array_sum(array_map(fn($a) => (int)$a['nota'], $avaliacoes)) / count($avaliacoes);
}

$relStmt = $pdo->prepare(
    'SELECT id, nome, preco, imagem
     FROM produtos
     WHERE ativo = 1 AND categoria = ? AND id <> ?
     ORDER BY id DESC LIMIT 4'
);
$relStmt->execute([$produto['categoria'], $id]);
$relacionados = $relStmt->fetchAll(PDO::FETCH_ASSOC);

$mensagem = $_SESSION['mensagem_produto'] ?? '';
unset($_SESSION['mensagem_produto']);
$quantidadeCarrinho = array_sum(array_map('intval', $_SESSION['carrinho']));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($produto['nome']) ?> | MBM Suplementos</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{--red:#ed101b;--red2:#ff3039;--bg:#070708;--panel:#111113;--line:#29292e;--muted:#999;--white:#fff}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Poppins,Arial,sans-serif;background:var(--bg);color:var(--white);min-height:100vh}
a{color:inherit;text-decoration:none}
header{height:76px;background:#050506;border-bottom:1px solid var(--line);position:sticky;top:0;z-index:5}
.header-inner{width:min(1200px,94%);height:100%;margin:auto;display:flex;align-items:center;justify-content:space-between;gap:20px}
.logo img{width:135px;max-height:58px;object-fit:contain}
.nav{display:flex;gap:24px;font-size:13px;font-weight:800}
.nav a:hover,.back:hover{color:var(--red)}
.cart{font-size:20px;position:relative}
.count{position:absolute;top:-9px;right:-10px;background:var(--red);border-radius:50%;font-size:10px;min-width:18px;height:18px;display:grid;place-items:center}
.wrap{width:min(1200px,94%);margin:30px auto 70px}
.breadcrumb{color:#888;font-size:12px;margin-bottom:24px}
.breadcrumb a{color:#ddd}
.product{display:grid;grid-template-columns:1fr 1fr;gap:45px;background:linear-gradient(145deg,#151517,#0c0c0e);border:1px solid var(--line);border-radius:18px;padding:30px}
.gallery{min-height:430px;border:1px solid #29292e;border-radius:14px;background:radial-gradient(ellipse,#242428,transparent 70%);display:grid;place-items:center;padding:20px}
.gallery img{width:100%;height:390px;object-fit:contain;filter:drop-shadow(0 14px 20px #000)}
.no-image{font-size:70px}
.category{font-size:11px;color:var(--red);font-weight:900;letter-spacing:2px;text-transform:uppercase}
h1{font-family:Montserrat,sans-serif;font-size:32px;line-height:1.2;margin:12px 0}
.price{font-family:Montserrat,sans-serif;font-size:32px;font-weight:900;color:var(--red);margin:18px 0}
.stock{font-size:12px;color:#aaa;margin-bottom:18px}
.description{color:#bbb;line-height:1.8;font-size:14px;margin:20px 0}
.rating-line{color:#ffc83d;font-size:14px;margin:10px 0}
.rating-line span{color:#999;font-size:12px;margin-left:8px}
.buy-form{display:flex;gap:12px;align-items:center;margin:22px 0}
.qty{width:85px;background:#09090b;border:1px solid #39393e;color:white;border-radius:8px;padding:14px}
.btn{border:0;border-radius:8px;background:var(--red);color:white;font-weight:900;padding:15px 20px;cursor:pointer;transition:.2s}
.btn:hover{background:var(--red2);transform:translateY(-2px)}
.btn:disabled{opacity:.45;cursor:not-allowed;transform:none}
.trust{display:grid;gap:10px;border-top:1px solid var(--line);padding-top:18px;color:#aaa;font-size:12px}
.shipping,.reviews,.related{margin-top:32px;background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:26px}
h2{font-family:Montserrat,sans-serif;font-size:22px;margin-bottom:16px}
.shipping p,.muted{color:#999;font-size:12px;line-height:1.6}
.cep-row{display:flex;gap:10px;margin:16px 0;max-width:460px}
.cep-row input{flex:1;min-width:0;background:#08080a;border:1px solid #38383e;border-radius:8px;color:white;padding:13px}
.shipping-result{font-size:13px;line-height:1.7;color:#ddd;min-height:24px}
.notice{padding:12px 15px;border:1px solid #315d3c;background:#102016;color:#b8edc2;border-radius:9px;margin-bottom:18px;font-size:13px}
.error{padding:12px 15px;border:1px solid #71343a;background:#260f12;color:#ffb9be;border-radius:9px;margin:12px 0;font-size:13px}
.review-grid{display:grid;grid-template-columns:340px 1fr;gap:28px}
.review-form{display:grid;gap:12px}
.review-form input,.review-form textarea,.review-form select{width:100%;background:#08080a;border:1px solid #38383e;border-radius:8px;color:white;padding:12px;font:inherit}
.review-form textarea{min-height:110px;resize:vertical}
.review-form label{font-size:12px;color:#bbb}
.review-card{border-bottom:1px solid var(--line);padding:15px 0}
.review-card:last-child{border:0}
.stars{color:#ffc83d;letter-spacing:2px}
.review-card p{color:#bbb;font-size:13px;line-height:1.7;margin-top:7px}
.review-meta{font-size:11px;color:#888;margin-top:5px}
.related-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.related-card{border:1px solid var(--line);background:#0b0b0d;border-radius:12px;padding:14px;text-align:center}
.related-card img{height:130px;width:100%;object-fit:contain}
.related-card strong{display:block;font-size:12px;margin:8px 0}
.related-card b{color:var(--red)}
footer{text-align:center;border-top:1px solid var(--line);padding:28px;color:#777;font-size:12px}
footer strong{color:var(--red)}
@media(max-width:760px){.nav{gap:12px;font-size:11px}.product{grid-template-columns:1fr;padding:16px;gap:22px}.gallery{min-height:280px}.gallery img{height:260px}h1{font-size:25px}.review-grid{grid-template-columns:1fr}.related-grid{grid-template-columns:repeat(2,1fr)}.buy-form{flex-wrap:wrap}.shipping,.reviews,.related{padding:18px}}
</style>
</head>
<body>
<header><div class="header-inner">
<a class="logo" href="loja.php"><img src="img/mbm logo sem fundo.png" alt="MBM Suplementos"></a>
<nav class="nav"><a href="loja.php">Início</a><a href="produtos.php">Produtos</a></nav>
<a class="cart" href="carrinho.php" aria-label="Carrinho">🛒<?php if($quantidadeCarrinho):?><span class="count"><?= $quantidadeCarrinho ?></span><?php endif;?></a>
</div></header>

<main class="wrap">
<div class="breadcrumb"><a href="loja.php">Início</a> / <a href="produtos.php">Produtos</a> / <?= e($produto['nome']) ?></div>

<?php if($mensagem): ?><div class="notice"><?= e($mensagem) ?></div><?php endif; ?>

<section class="product">
    <div class="gallery">
        <?php if($imagem !== ''): ?>
            <img src="<?= e($imagem) ?>" alt="<?= e($produto['nome']) ?>">
        <?php else: ?><div class="no-image">🥤</div><?php endif; ?>
    </div>
    <div>
        <div class="category"><?= e($produto['categoria'] ?: 'Suplemento') ?></div>
        <h1><?= e($produto['nome']) ?></h1>
        <div class="rating-line"><?= $avaliacoes ? str_repeat('★', (int)round($media)) . str_repeat('☆', 5-(int)round($media)) : '☆☆☆☆☆' ?>
            <span><?= $avaliacoes ? number_format($media,1,',','.') . ' / 5 (' . count($avaliacoes) . ' avaliações)' : 'Ainda sem avaliações' ?></span>
        </div>
        <div class="price">R$ <?= number_format((float)$produto['preco'],2,',','.') ?></div>
        <div class="stock"><?= (int)$produto['estoque'] > 0 ? '✓ Em estoque: ' . (int)$produto['estoque'] . ' unidade(s)' : 'Produto indisponível no momento' ?></div>
        <p class="description"><?= nl2br(e($produto['descricao'] ?: 'Produto selecionado pela MBM Suplementos para sua rotina.')) ?></p>
        <form class="buy-form" method="post">
            <input type="hidden" name="acao" value="adicionar">
            <label for="quantidade" class="muted">Qtd.</label>
            <input class="qty" id="quantidade" type="number" name="quantidade" min="1" max="<?= max(1,min(20,(int)$produto['estoque'])) ?>" value="1" <?= (int)$produto['estoque']<1?'disabled':'' ?>>
            <button class="btn" type="submit" <?= (int)$produto['estoque']<1?'disabled':'' ?>>🛒 ADICIONAR AO CARRINHO</button>
        </form>
        <div class="trust"><div>✓ Compra com atendimento MBM</div><div>✓ Consulte o prazo estimado pelo seu CEP</div><div>✓ Produto cadastrado diretamente no estoque da loja</div></div>
    </div>
</section>

<section class="shipping">
    <h2>Calcular frete e prazo</h2>
    <p>Informe seu CEP para consultar uma estimativa de entrega. Origem: 12312-000 (SP). O valor não é uma cotação oficial de transportadora.</p>
    <div class="cep-row">
        <input id="cep" type="text" inputmode="numeric" maxlength="9" placeholder="Digite seu CEP (00000-000)" aria-label="CEP de destino">
        <button class="btn" type="button" id="calcularFrete">CALCULAR</button>
    </div>
    <div id="freteResultado" class="shipping-result" aria-live="polite"></div>
</section>

<section class="reviews" id="avaliacoes">
    <h2>Avaliações dos clientes</h2>
    <div class="review-grid">
        <div>
            <p class="muted">Conte como foi sua experiência com este produto.</p>
            <?php if($erroAvaliacao): ?><div class="error"><?= e($erroAvaliacao) ?></div><?php endif; ?>
            <form class="review-form" method="post">
                <input type="hidden" name="acao" value="avaliar">
                <input type="hidden" name="csrf" value="<?= e($_SESSION['csrf_avaliacao']) ?>">
                <label>Seu nome</label>
                <input type="text" name="nome_avaliador" maxlength="100" required placeholder="Como podemos te chamar?">
                <label>Sua nota</label>
                <select name="nota" required>
                    <option value="">Selecione de 1 a 5 estrelas</option>
                    <option value="5">★★★★★ - Excelente</option>
                    <option value="4">★★★★☆ - Muito bom</option>
                    <option value="3">★★★☆☆ - Bom</option>
                    <option value="2">★★☆☆☆ - Regular</option>
                    <option value="1">★☆☆☆☆ - Ruim</option>
                </select>
                <label>Comentário</label>
                <textarea name="comentario" minlength="5" maxlength="1500" required placeholder="Escreva sua opinião sobre o produto..."></textarea>
                <button class="btn" type="submit">ENVIAR AVALIAÇÃO</button>
            </form>
        </div>
        <div>
            <?php if(!$avaliacoes): ?>
                <p class="muted">Este produto ainda não recebeu avaliações. Seja o primeiro a avaliar!</p>
            <?php else: foreach($avaliacoes as $av): ?>
                <article class="review-card">
                    <div class="stars"><?= str_repeat('★',(int)$av['nota']) . str_repeat('☆',5-(int)$av['nota']) ?></div>
                    <strong><?= e($av['nome']) ?></strong>
                    <p><?= nl2br(e($av['comentario'])) ?></p>
                    <div class="review-meta"><?= date('d/m/Y',strtotime($av['criado_em'])) ?></div>
                </article>
            <?php endforeach; endif; ?>
        </div>
    </div>
</section>

<?php if($relacionados): ?>
<section class="related">
    <h2>Você também pode gostar</h2>
    <div class="related-grid">
    <?php foreach($relacionados as $rel):
        $relImg = imagemDoProdutoDetalhe($rel, is_array($imagensProdutos) ? $imagensProdutos : []);
    ?>
        <a class="related-card" href="produto.php?id=<?= (int)$rel['id'] ?>">
            <?php if($relImg): ?><img src="<?= e($relImg) ?>" alt="<?= e($rel['nome']) ?>"><?php else: ?><div style="height:130px;display:grid;place-items:center;font-size:42px">🥤</div><?php endif; ?>
            <strong><?= e($rel['nome']) ?></strong>
            <b>R$ <?= number_format((float)$rel['preco'],2,',','.') ?></b>
        </a>
    <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>
</main>
<footer><strong>MBM SUPLEMENTOS</strong><p>Performance • Força • Resultado</p><p>© <?= date('Y') ?> MBM Suplementos. Todos os direitos reservados.</p></footer>

<script>
const cepInput = document.getElementById('cep');
const resultadoFrete = document.getElementById('freteResultado');
const botaoFrete = document.getElementById('calcularFrete');
const campoQtd = document.getElementById('quantidade');

cepInput.addEventListener('input', () => {
    let v = cepInput.value.replace(/\D/g, '').slice(0, 8);
    cepInput.value = v.length > 5 ? v.slice(0,5) + '-' + v.slice(5) : v;
});

botaoFrete.addEventListener('click', async () => {
    const cep = cepInput.value.replace(/\D/g, '');
    if (cep.length !== 8) {
        resultadoFrete.textContent = 'Digite um CEP válido com 8 números.';
        return;
    }
    botaoFrete.disabled = true;
    resultadoFrete.textContent = 'Consultando CEP e calculando estimativa...';
    try {
        const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
        if (!resposta.ok) throw new Error('Não foi possível consultar o CEP agora.');
        const local = await resposta.json();
        if (local.erro) throw new Error('CEP não encontrado. Confira os números digitados.');

        const uf = (local.uf || '').toUpperCase();
        const faixas = {
            SP: {valor: 14.90, prazo: '2 a 5 dias úteis'},
            RJ: {valor: 22.90, prazo: '4 a 7 dias úteis'},
            ES: {valor: 24.90, prazo: '4 a 7 dias úteis'},
            MG: {valor: 22.90, prazo: '4 a 7 dias úteis'},
            PR: {valor: 27.90, prazo: '5 a 8 dias úteis'},
            SC: {valor: 29.90, prazo: '5 a 9 dias úteis'},
            RS: {valor: 32.90, prazo: '6 a 10 dias úteis'},
            DF: {valor: 31.90, prazo: '5 a 9 dias úteis'},
            GO: {valor: 33.90, prazo: '5 a 9 dias úteis'},
            MS: {valor: 34.90, prazo: '6 a 10 dias úteis'},
            MT: {valor: 36.90, prazo: '6 a 11 dias úteis'},
            BA: {valor: 36.90, prazo: '7 a 12 dias úteis'},
            SE: {valor: 38.90, prazo: '7 a 12 dias úteis'},
            AL: {valor: 39.90, prazo: '7 a 12 dias úteis'},
            PE: {valor: 39.90, prazo: '7 a 12 dias úteis'},
            PB: {valor: 41.90, prazo: '8 a 13 dias úteis'},
            RN: {valor: 41.90, prazo: '8 a 13 dias úteis'},
            CE: {valor: 43.90, prazo: '8 a 14 dias úteis'},
            PI: {valor: 43.90, prazo: '8 a 14 dias úteis'},
            MA: {valor: 45.90, prazo: '9 a 15 dias úteis'},
            TO: {valor: 39.90, prazo: '7 a 12 dias úteis'},
            PA: {valor: 47.90, prazo: '9 a 16 dias úteis'},
            RO: {valor: 49.90, prazo: '9 a 16 dias úteis'},
            AC: {valor: 54.90, prazo: '10 a 18 dias úteis'},
            AM: {valor: 54.90, prazo: '10 a 18 dias úteis'},
            RR: {valor: 59.90, prazo: '11 a 20 dias úteis'},
            AP: {valor: 54.90, prazo: '10 a 18 dias úteis'}
        };
        const faixa = faixas[uf];
        if (!faixa) throw new Error('Não foi possível estimar a entrega para este estado.');
        const qtd = Math.max(1, Math.min(20, parseInt(campoQtd?.value || '1', 10)));
        const frete = faixa.valor + (qtd - 1) * 3.50;
        resultadoFrete.innerHTML =
            `<strong>Frete estimado: R$ ${frete.toFixed(2).replace('.', ',')}</strong><br>` +
            `Prazo estimado: ${faixa.prazo}<br>` +
            `Destino: ${local.localidade || ''} - ${uf}. Estimativa para ${qtd} unidade(s).`;
    } catch (erro) {
        resultadoFrete.textContent = erro.message || 'Erro ao calcular o frete. Tente novamente.';
    } finally {
        botaoFrete.disabled = false;
    }
});
</script>
</body>
</html>
