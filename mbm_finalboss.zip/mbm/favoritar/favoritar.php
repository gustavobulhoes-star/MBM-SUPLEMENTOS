<?php
session_start();
require_once __DIR__ . '/../config/database.php';

// Garante que a tabela favoritos existe com as colunas corretas
$pdo->exec("
    CREATE TABLE IF NOT EXISTS favoritos (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT UNSIGNED NOT NULL,
        produto_id INT UNSIGNED NOT NULL,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_usuario_produto (usuario_id, produto_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$colunasFav = $pdo->query("SHOW COLUMNS FROM favoritos")->fetchAll(PDO::FETCH_COLUMN);
if (!in_array('usuario_id', $colunasFav)) {
    $pdo->exec("ALTER TABLE favoritos ADD COLUMN usuario_id INT UNSIGNED NOT NULL");
}
if (!in_array('produto_id', $colunasFav)) {
    $pdo->exec("ALTER TABLE favoritos ADD COLUMN produto_id INT UNSIGNED NOT NULL");
}

$usuarioId = (int)($_SESSION['usuario_id'] ?? 0);
$produtoId = filter_input(INPUT_POST, 'produto_id', FILTER_VALIDATE_INT);
$isAjax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest';

if ($usuarioId <= 0) {
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'nao_logado', 'redirect' => 'index.php?modo=login']);
        exit;
    }
    header('Location: ../index.php?modo=login');
    exit;
}

if ($produtoId) {
    try {
        $stmtCheck = $pdo->prepare('SELECT id FROM favoritos WHERE usuario_id = ? AND produto_id = ? LIMIT 1');
        $stmtCheck->execute([$usuarioId, $produtoId]);
        $existe = $stmtCheck->fetch();

        if ($existe) {
            $stmtDel = $pdo->prepare('DELETE FROM favoritos WHERE id = ?');
            $stmtDel->execute([$existe['id']]);
            $favoritado = false;
        } else {
            $stmtIns = $pdo->prepare('INSERT INTO favoritos (usuario_id, produto_id) VALUES (?, ?)');
            $stmtIns->execute([$usuarioId, $produtoId]);
            $favoritado = true;
        }

        if ($isAjax) {
            header('Content-Type: application/json');
            echo json_encode(['status' => 'ok', 'favoritado' => $favoritado]);
            exit;
        }
    } catch (PDOException $e) {
        if ($isAjax) {
            header('Content-Type: application/json');
            echo json_encode(['status' => 'erro', 'mensagem' => $e->getMessage()]);
            exit;
        }
    }
}

$voltar = $_SERVER['HTTP_REFERER'] ?? 'favoritos.php';
header('Location: ' . $voltar);
exit;