<?php
session_start();
require_once __DIR__ . '/../config/database.php';

$pdo->exec("
    CREATE TABLE IF NOT EXISTS favoritos (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT UNSIGNED NOT NULL,
        produto_id INT UNSIGNED NOT NULL,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_usuario_produto (usuario_id, produto_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

function e($valor): string {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

if (!isset($_SESSION['carrinho']) || !is_array($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

$usuarioIdSessao = (int)($_SESSION['usuario_id'] ?? 0);

if ($usuarioIdSessao <= 0) {
    header('Location: ../index.php?modo=login');
    exit;
}

// Adicionar ao carrinho direto da aba favoritos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'adicionar') {
    $produtoId = filter_input(INPUT_POST, 'produto_id', FILTER_VALIDATE_INT);

    if ($produtoId) {
        $stmt = $pdo->prepare("SELECT id, estoque FROM produtos WHERE id = ? AND ativo = 1 LIMIT 1");
        $stmt->execute([$produtoId]);
        $prod = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($prod && (int)$prod['estoque'] > (int)($_SESSION['carrinho'][$produtoId] ?? 0)) {
            $_SESSION['carrinho'][$produtoId] = (int)($_SESSION['carrinho'][$produtoId] ?? 0) + 1;
            header('Location: ../carrinho.php');
            exit;
        }
    }
}

$arquivoImagens = __DIR__ . '/../config/imagens-produtos.php';
$imagensProdutos = file_exists($arquivoImagens) ? require $arquivoImagens : [];

function imagemDoProduto(array $produto, array $imagens): string {
    $nome = mb_strtolower(trim($produto['nome']), 'UTF-8');
    $caminhoEncontrado = '';

    foreach ($imagens as $termo => $caminho) {
        if (mb_strpos($nome, mb_strtolower($termo, 'UTF-8')) !== false) {
            $caminhoEncontrado = $caminho;
            break;
        }
    }

    if ($caminhoEncontrado === '') {
        $caminhoEncontrado = trim((string)($produto['imagem'] ?? ''));
    }

    if ($caminhoEncontrado !== '' && !preg_match('#^(https?://|/|\.\./)#i', $caminhoEncontrado)) {
        return '../' . $caminhoEncontrado;
    }

    return $caminhoEncontrado;
}

// Buscar produtos favoritados pelo usuário no banco
$stmt = $pdo->prepare("
    SELECT
        p.id, p.nome, p.descricao, p.preco, p.estoque, p.categoria, p.imagem,
        f.criado_em AS favoritado_em
    FROM favoritos f
    INNER JOIN produtos p ON p.id = f.produto_id
    WHERE f.usuario_id = ? AND p.ativo = 1
    ORDER BY f.criado_em DESC
");
$stmt->execute([$usuarioIdSessao]);
$favoritos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$quantidadeCarrinho = array_sum(array_map('intval', $_SESSION['carrinho']));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Meus Favoritos | MBM Suplementos</title>
<style>
:root {
    --red: #ed101b;
    --red2: #ff3039;
    --bg: #070708;
    --panel: #121214;
    --line: #29292e;
    --muted: #999;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: Arial, Helvetica, sans-serif; background: var(--bg); color: #fff; min-height: 100vh; display: flex; flex-direction: column; }
a { color: inherit; text-decoration: none; }

.header {
    height: 76px; background: #060607; border-bottom: 1px solid var(--line);
    display: flex; align-items: center; position: sticky; top: 0; z-index: 50;
}
.header-inner {
    width: min(1250px, 92%); margin: auto; display: flex;
    align-items: center; justify-content: space-between; gap: 20px;
}
.logo img { width: 145px; max-height: 55px; object-fit: contain; }
nav { display: flex; align-items: center; gap: 25px; font-size: 13px; font-weight: 800; }
nav a:hover, nav a.active { color: var(--red); }
.cart { background: var(--red); color: #fff !important; padding: 11px 15px; border-radius: 7px; }

.page { width: min(1250px, 92%); margin: auto; padding: 55px 0 90px; flex: 1; }
.kicker { color: var(--red); font-size: 11px; font-weight: 900; letter-spacing: 3px; }
.heading {
    display: flex; justify-content: space-between; align-items: end;
    margin: 10px 0 30px; gap: 15px;
}
.heading h1 { font-size: clamp(28px, 4vw, 40px); }
.heading p { color: var(--muted); font-size: 13px; margin-top: 8px; }
.heading a { color: var(--red); font-size: 12px; font-weight: 800; }

.grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 18px; }
.card {
    background: linear-gradient(145deg, #19191c, #0d0d0f);
    border: 1px solid var(--line); border-radius: 12px;
    overflow: hidden; transition: .25s; position: relative; cursor: pointer;
}
.card:hover { border-color: var(--red); transform: translateY(-4px); }

.fav-btn {
    position: absolute; top: 12px; right: 12px; width: 36px; height: 36px;
    border-radius: 50%; border: 1px solid var(--red); background: var(--red);
    color: #fff; font-size: 18px; cursor: pointer; display: grid; place-items: center;
    z-index: 10; transition: .2s;
}
.fav-btn:hover { background: #222; border-color: #555; }

.photo {
    height: 240px; display: flex; align-items: center; justify-content: center;
    padding: 10px; background: radial-gradient(ellipse, #29292d, transparent 72%);
}
.photo img {
    width: 100%; height: 100%; object-fit: contain; transition: .3s;
    filter: drop-shadow(0 10px 15px #000);
}
.card:hover .photo img { transform: scale(1.04); }

.info { padding: 17px; }
.category { font-size: 10px; color: var(--red); font-weight: 900; letter-spacing: 1.5px; text-transform: uppercase; }
.name { font-size: 17px; font-weight: 900; line-height: 1.4; margin: 8px 0 6px; }
.card:hover .name { color: var(--red); }
.desc { font-size: 11px; line-height: 1.5; color: #888; min-height: 34px; }
.price { font-size: 22px; font-weight: 900; color: var(--red); margin: 14px 0; }
.stock { color: #999; font-size: 10px; margin-bottom: 12px; }

.buy {
    width: 100%; border: 0; border-radius: 7px; padding: 12px;
    background: var(--red); color: #fff; font-size: 11px;
    font-weight: 900; cursor: pointer; transition: .2s;
}
.buy:hover { background: var(--red2); }
.buy:disabled { background: #444; cursor: not-allowed; }

.empty {
    padding: 60px 25px; text-align: center; border: 1px solid var(--line);
    border-radius: 14px; background: #0e0e11; grid-column: 1 / -1;
}
.empty h3 { font-size: 20px; margin-bottom: 10px; }
.empty p { color: var(--muted); font-size: 13px; margin-bottom: 22px; }
.btn-explore {
    display: inline-block; background: var(--red); color: #fff;
    padding: 12px 24px; border-radius: 8px; font-size: 12px; font-weight: 900;
}

footer { text-align: center; padding: 30px; color: #777; border-top: 1px solid var(--line); font-size: 12px; }
footer strong { color: var(--red); }

@media(max-width: 950px) { .grid { grid-template-columns: repeat(2, 1fr); } }
@media(max-width: 600px) {
    .header { height: auto; padding: 14px 0; }
    .header-inner { flex-wrap: wrap; }
    .grid { grid-template-columns: 1fr; }
    .heading { display: block; }
}
</style>
</head>
<body>

<header class="header">
    <div class="header-inner">
        <a class="logo" href="../loja.php">
            <img src="../img/mbm logo sem fundo.png" alt="MBM Suplementos">
        </a>
        <nav>
            <a href="../loja.php">Início</a>
            <a href="../produtos.php">Produtos</a>
            <a href="favoritos.php" class="active">♥ Favoritos</a>
            <a class="cart" href="../carrinho.php">🛒 Carrinho (<?= $quantidadeCarrinho ?>)</a>
        </nav>
    </div>
</header>

<main class="page">
    <div class="kicker">SUA LISTA DE DESEJOS</div>

    <div class="heading">
        <div>
            <h1>Meus Favoritos (<?= count($favoritos) ?>)</h1>
            <p>Produtos que você salvou para acompanhar ou comprar depois.</p>
        </div>
        <a href="../produtos.php">← Continuar explorando</a>
    </div>

    <div class="grid" id="favoritosGrid">
        <?php if (!$favoritos): ?>
            <div class="empty">
                <h3>Você ainda não tem produtos favoritos</h3>
                <p>Clique no ícone de coração (♡) em qualquer produto da loja para salvá-lo aqui.</p>
                <a href="../produtos.php" class="btn-explore">VER PRODUTOS</a>
            </div>
        <?php endif; ?>

        <?php foreach ($favoritos as $produto): ?>
            <?php
            $img = imagemDoProduto($produto, $imagensProdutos);
            $semEstoque = (int)$produto['estoque'] <= 0;
            $linkProduto = '../produtos.php?id=' . (int)$produto['id'];
            ?>

            <article class="card" id="card-fav-<?= (int)$produto['id'] ?>" onclick="window.location.href='<?= $linkProduto ?>'">
                <button type="button"
                        class="fav-btn"
                        onclick="event.stopPropagation(); removerFavorito(<?= (int)$produto['id'] ?>)"
                        title="Remover dos favoritos">
                    ♥
                </button>

                <div class="photo">
                    <?php if ($img !== ''): ?>
                        <img src="<?= e($img) ?>" alt="<?= e($produto['nome']) ?>" loading="lazy">
                    <?php else: ?>
                        <span style="font-size:48px">🥤</span>
                    <?php endif; ?>
                </div>

                <div class="info">
                    <div class="category"><?= e($produto['categoria'] ?? 'Suplemento') ?></div>
                    <div class="name"><a href="<?= $linkProduto ?>"><?= e($produto['nome']) ?></a></div>
                    <p class="desc"><?= e($produto['descricao'] ?? '') ?></p>

                    <div class="price">
                        R$ <?= number_format((float)$produto['preco'], 2, ',', '.') ?>
                    </div>

                    <div class="stock">
                        <?= $semEstoque ? 'Produto indisponível' : 'Disponível em estoque' ?>
                    </div>

                    <form method="post" onclick="event.stopPropagation()">
                        <input type="hidden" name="acao" value="adicionar">
                        <input type="hidden" name="produto_id" value="<?= (int)$produto['id'] ?>">
                        <button class="buy" type="submit" <?= $semEstoque ? 'disabled' : '' ?>>
                            🛒 <?= $semEstoque ? 'SEM ESTOQUE' : 'ADICIONAR AO CARRINHO' ?>
                        </button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</main>

<footer>
    <strong>MBM SUPLEMENTOS</strong>
    <p>Performance • Força • Resultado</p>
    <p>© <?= date('Y') ?> MBM Suplementos. Todos os direitos reservados.</p>
</footer>

<script>
function removerFavorito(produtoId) {
    const formData = new FormData();
    formData.append('produto_id', produtoId);

    fetch('favoritar.php', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === 'ok' && !data.favoritado) {
            const card = document.getElementById('card-fav-' + produtoId);
            if (card) card.remove();
            if (document.querySelectorAll('.card').length === 0) {
                location.reload();
            }
        }
    });
}
</script>
</body>
</html>