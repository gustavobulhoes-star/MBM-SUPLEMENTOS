<?php
session_start();
require_once __DIR__ . '/config/database.php';

if (empty($_SESSION['usuario_id'])) {
    header('Location: index.php?modo=login');
    exit;
}

$usuarioId = (int)$_SESSION['usuario_id'];
$stmt = $pdo->prepare('SELECT id, nome, email, foto_perfil FROM usuarios WHERE id = ? LIMIT 1');
$stmt->execute([$usuarioId]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    session_unset();
    session_destroy();
    header('Location: index.php?modo=login');
    exit;
}

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'foto') {
    if (!isset($_FILES['foto']) || $_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
        $erro = 'Selecione uma imagem válida.';
    } elseif ($_FILES['foto']['size'] > 3 * 1024 * 1024) {
        $erro = 'A imagem deve ter no máximo 3 MB.';
    } else {
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($_FILES['foto']['tmp_name']);
        $permitidos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];

        if (!isset($permitidos[$mime]) || @getimagesize($_FILES['foto']['tmp_name']) === false) {
            $erro = 'Formato inválido. Envie JPG, PNG ou WEBP.';
        } else {
            $pasta = __DIR__ . '/uploads/perfis';
            if (!is_dir($pasta) && !mkdir($pasta, 0755, true)) {
                $erro = 'Não foi possível criar a pasta de fotos no servidor.';
            } else {
                $nomeArquivo = 'perfil_' . $usuarioId . '_' . bin2hex(random_bytes(8)) . '.' . $permitidos[$mime];
                $destino = $pasta . '/' . $nomeArquivo;
                if (move_uploaded_file($_FILES['foto']['tmp_name'], $destino)) {
                    $caminho = 'uploads/perfis/' . $nomeArquivo;
                    $upd = $pdo->prepare('UPDATE usuarios SET foto_perfil = ? WHERE id = ?');
                    $upd->execute([$caminho, $usuarioId]);
                    if (!empty($usuario['foto_perfil'])) {
                        $fotoAntiga = __DIR__ . '/' . $usuario['foto_perfil'];
                        if (is_file($fotoAntiga) && strpos(realpath($fotoAntiga), realpath($pasta) . DIRECTORY_SEPARATOR) === 0) {
                            @unlink($fotoAntiga);
                        }
                    }
                    header('Location: conta.php?foto=ok');
                    exit;
                } else {
                    $erro = 'Não foi possível salvar a foto. Verifique as permissões da pasta.';
                }
            }
        }
    }
}

if (isset($_GET['foto']) && $_GET['foto'] === 'ok') {
    $sucesso = 'Foto de perfil atualizada com sucesso!';
}
function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Minha conta | MBM Suplementos</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#080809;color:#fff;font-family:Arial,sans-serif}
header{height:70px;background:#050506;border-bottom:1px solid #29292e;display:flex;align-items:center;padding:0 max(4%,calc((100% - 1100px)/2))}
header a{color:#fff;text-decoration:none;font-weight:bold}.wrap{width:min(900px,92%);margin:45px auto}
h1{font-size:28px;margin:0 0 8px}.muted{color:#999;font-size:14px}
.panel{background:#131315;border:1px solid #303035;border-radius:14px;padding:25px;margin-top:24px}
.profile{display:flex;align-items:center;gap:22px;flex-wrap:wrap}
.avatar{width:105px;height:105px;border-radius:50%;background:#29292e;display:grid;place-items:center;overflow:hidden;font-size:38px;font-weight:bold}
.avatar img{width:100%;height:100%;object-fit:cover}
h2{font-size:18px;margin:0 0 18px}.btn{display:inline-block;background:#ed101b;color:#fff;border:0;border-radius:7px;padding:12px 17px;font-weight:bold;cursor:pointer;text-decoration:none}
input[type=file]{display:block;margin:15px 0;color:#ccc;max-width:100%}
.msg{padding:12px;border-radius:7px;margin:15px 0;font-size:14px}.err{background:#491a1d;color:#ffb9bd}.ok{background:#173a25;color:#b7f5c9}
.info{line-height:1.9;color:#ccc}.info b{color:#fff}
@media(max-width:600px){.wrap{margin:28px auto}.panel{padding:18px}.profile{gap:14px}}
</style>
</head>
<body>
<header><a href="loja.php">← VOLTAR PARA A LOJA</a></header>
<main class="wrap">
<h1>Minha conta</h1><p class="muted">Gerencie suas informações e sua foto de perfil.</p>
<?php if($erro): ?><div class="msg err"><?=e($erro)?></div><?php endif; ?>
<?php if($sucesso): ?><div class="msg ok"><?=e($sucesso)?></div><?php endif; ?>
<section class="panel">
<div class="profile">
<div class="avatar"><?php if($usuario['foto_perfil']): ?><img src="<?=e($usuario['foto_perfil'])?>" alt="Foto de perfil"><?php else: ?><?=e(mb_strtoupper(mb_substr($usuario['nome'],0,1,'UTF-8'),'UTF-8'))?><?php endif; ?></div>
<div><h2><?=e($usuario['nome'])?></h2><p class="muted"><?=e($usuario['email'])?></p></div>
</div>
<hr style="border:0;border-top:1px solid #303035;margin:24px 0">
<h2>Alterar foto de perfil</h2>
<form method="post" enctype="multipart/form-data">
<input type="hidden" name="acao" value="foto">
<input type="file" name="foto" accept="image/jpeg,image/png,image/webp" required>
<p class="muted">Formatos aceitos: JPG, PNG ou WEBP. Tamanho máximo: 3 MB.</p><br>
<button class="btn" type="submit">Salvar foto</button>
</form>
</section>
<section class="panel">
<h2>Dados da conta</h2>
<div class="info"><b>Nome:</b> <?=e($usuario['nome'])?><br><b>E-mail:</b> <?=e($usuario['email'])?></div>
</section>
<section class="panel">
<h2>Seus pedidos</h2>
<p class="muted">Acompanhe compras e atualizações dos seus pedidos.</p><br>
<a class="btn" href="meus-pedidos.php">VER MEUS PEDIDOS</a>
</section>
</main>
</body>
</html>