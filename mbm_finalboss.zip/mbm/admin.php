<?php
session_start();

require_once __DIR__ . '/config/database.php';

// Configuração da criptografia AES-256-CBC + HEX (mesma chave e IV do banco)
define('AES_KEY', 'MBM_CHAVE_SECRETA_2026_32BYTES!!');
define('AES_IV',  '1234567890123456');

function criptografarSenha($senha) {
    $cifrado = openssl_encrypt((string)$senha, 'AES-256-CBC', AES_KEY, OPENSSL_RAW_DATA, AES_IV);
    return strtoupper(bin2hex($cifrado));
}

function descriptografarSenha($senhaHex) {
    $binario = @hex2bin((string)$senhaHex);
    if ($binario === false) {
        return '';
    }
    return (string)openssl_decrypt($binario, 'AES-256-CBC', AES_KEY, OPENSSL_RAW_DATA, AES_IV);
}

function e($valor) {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

function redirecionar() {
    header('Location: admin.php');
    exit;
}

$logado = !empty($_SESSION['admin_id']);

// Se não estiver logado como admin, volta direto para o index.php (sem tela de login interna)
if (!$logado) {
    header('Location: index.php');
    exit;
}

$mensagem = $_SESSION['mensagem'] ?? '';
unset($_SESSION['mensagem']);

// Processamento dos formulários (somente administradores logados chegam aqui)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $acao = $_POST['acao'] ?? '';

    // SAIR
    if ($acao === 'sair') {
        $_SESSION = [];
        session_unset();
        session_destroy();
        header('Location: index.php');
        exit;
    }

    // CADASTRAR OU EDITAR PRODUTO
    if ($acao === 'salvar_produto') {

        $id = (int)($_POST['id'] ?? 0);
        $nome = trim($_POST['nome'] ?? '');
        $descricao = trim($_POST['descricao'] ?? '');
        $preco = str_replace(',', '.', $_POST['preco'] ?? '0');
        $estoque = (int)($_POST['estoque'] ?? 0);
        $categoria = trim($_POST['categoria'] ?? '');
        $imagem = trim($_POST['imagem_atual'] ?? '');

        if ($nome === '' || $categoria === '' || !is_numeric($preco) || $preco < 0 || $estoque < 0) {
            $_SESSION['mensagem'] = 'Confira os dados do produto.';
            redirecionar();
        }

        // Upload de imagem
        if (
            isset($_FILES['imagem']) &&
            $_FILES['imagem']['error'] !== UPLOAD_ERR_NO_FILE
        ) {
            if ($_FILES['imagem']['error'] !== UPLOAD_ERR_OK) {
                $_SESSION['mensagem'] = 'Erro ao enviar a imagem.';
                redirecionar();
            }

            $diretorio = __DIR__ . '/img/produtos/';

            if (!is_dir($diretorio)) {
                mkdir($diretorio, 0775, true);
            }

            $info = getimagesize($_FILES['imagem']['tmp_name']);

            if ($info === false) {
                $_SESSION['mensagem'] = 'O arquivo enviado não é uma imagem válida.';
                redirecionar();
            }

            $tiposPermitidos = [
                'image/jpeg' => 'jpg',
                'image/png' => 'png',
                'image/webp' => 'webp'
            ];

            $mime = $info['mime'];

            if (!isset($tiposPermitidos[$mime])) {
                $_SESSION['mensagem'] = 'Use uma imagem JPG, PNG ou WEBP.';
                redirecionar();
            }

            $nomeArquivo = bin2hex(random_bytes(12)) . '.' . $tiposPermitidos[$mime];

            if (!move_uploaded_file(
                $_FILES['imagem']['tmp_name'],
                $diretorio . $nomeArquivo
            )) {
                $_SESSION['mensagem'] = 'Não foi possível salvar a imagem.';
                redirecionar();
            }

            $imagem = 'img/produtos/' . $nomeArquivo;
        }

        if ($id > 0) {

            $atualizar = $pdo->prepare("
                UPDATE produtos
                SET nome = ?, descricao = ?, preco = ?,
                    estoque = ?, categoria = ?, imagem = ?
                WHERE id = ?
            ");

            $atualizar->execute([
                $nome, $descricao, $preco,
                $estoque, $categoria, $imagem, $id
            ]);

            $_SESSION['mensagem'] = 'Produto atualizado com sucesso!';

        } else {

            $inserir = $pdo->prepare("
                INSERT INTO produtos
                (nome, descricao, preco, estoque, categoria, imagem, ativo)
                VALUES (?, ?, ?, ?, ?, ?, 1)
            ");

            $inserir->execute([
                $nome, $descricao, $preco,
                $estoque, $categoria, $imagem
            ]);

            $_SESSION['mensagem'] = 'Produto cadastrado com sucesso!';
        }

        redirecionar();
    }

    // EXCLUIR PRODUTO
    if ($acao === 'excluir_produto') {

        $id = (int)($_POST['id'] ?? 0);

        $consulta = $pdo->prepare("SELECT imagem FROM produtos WHERE id = ?");
        $consulta->execute([$id]);
        $produto = $consulta->fetch(PDO::FETCH_ASSOC);

        if ($produto) {
            $excluir = $pdo->prepare("DELETE FROM produtos WHERE id = ?");
            $excluir->execute([$id]);

            // Remove a imagem somente se estiver na pasta de produtos
            $imagem = $produto['imagem'] ?? '';

            if (
                strpos($imagem, 'img/produtos/') === 0 &&
                is_file(__DIR__ . '/' . $imagem)
            ) {
                unlink(__DIR__ . '/' . $imagem);
            }

            $_SESSION['mensagem'] = 'Produto excluído com sucesso!';
        }

        redirecionar();
    }
}

// Busca produto para edição
$produtoEdicao = null;

if (isset($_GET['editar'])) {
    $consulta = $pdo->prepare("SELECT * FROM produtos WHERE id = ?");
    $consulta->execute([(int)$_GET['editar']]);
    $produtoEdicao = $consulta->fetch(PDO::FETCH_ASSOC);
}

// Lista produtos
$consulta = $pdo->query("SELECT * FROM produtos ORDER BY id DESC");
$produtos = $consulta->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Administração MBM</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    background: #111;
    color: #fff;
    min-height: 100vh;
}

header {
    background: #1b1b1b;
    border-bottom: 3px solid #e50914;
    padding: 22px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 15px;
}

.logo {
    font-size: 27px;
    font-weight: bold;
    color: #e50914;
}

.container {
    width: 94%;
    max-width: 1150px;
    margin: 35px auto;
}

h1, h2 {
    margin-bottom: 20px;
}

h1 span, h2 span {
    color: #e50914;
}

p {
    color: #bbb;
    margin-bottom: 18px;
}

label {
    display: block;
    margin: 14px 0 7px;
    font-weight: bold;
}

input, textarea, select {
    width: 100%;
    padding: 13px;
    background: #292929;
    color: white;
    border: 1px solid #444;
    border-radius: 6px;
    outline: none;
}

input:focus, textarea:focus, select:focus {
    border-color: #e50914;
}

textarea {
    min-height: 90px;
    resize: vertical;
}

button, .botao {
    display: inline-block;
    padding: 12px 18px;
    background: #e50914;
    color: white;
    border: none;
    border-radius: 6px;
    cursor: pointer;
    font-weight: bold;
    text-decoration: none;
    margin-top: 12px;
}

button:hover, .botao:hover {
    background: #b80710;
}

.botao-secundario {
    background: #333;
}

.botao-excluir {
    background: #8b0000;
}

form {
    margin-bottom: 20px;
}

.mensagem {
    padding: 14px;
    background: #392020;
    border-left: 4px solid #e50914;
    border-radius: 5px;
    margin-bottom: 20px;
}

.colunas {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 25px;
}

.painel {
    background: #1c1c1c;
    padding: 25px;
    border-radius: 10px;
    margin-bottom: 25px;
}

.tabela {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.tabela th, .tabela td {
    padding: 12px;
    border-bottom: 1px solid #393939;
    text-align: left;
}

.tabela th {
    color: #e50914;
}

.tabela img {
    width: 55px;
    height: 55px;
    object-fit: contain;
    background: white;
    border-radius: 5px;
}

.acoes {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}

.acoes button, .acoes a {
    margin-top: 0;
}

@media(max-width: 750px) {
    .colunas {
        grid-template-columns: 1fr;
    }

    .tabela {
        font-size: 12px;
    }

    .tabela th, .tabela td {
        padding: 7px;
    }
}
</style>
</head>

<body>

<header>
    <div class="logo">MBM SUPLEMENTOS</div>

    <div style="display:flex; align-items:center; gap:12px; flex-wrap:wrap;">
        <span>Olá, <?= e($_SESSION['admin_nome'] ?? 'Administrador') ?></span>

        <a class="botao botao-secundario" href="loja.php" style="margin-top:0;">Ir para a loja</a>

        <form method="POST" style="display:inline; margin-bottom:0;">
            <input type="hidden" name="acao" value="sair">
            <button type="submit" style="margin-top:0;">Sair</button>
        </form>
    </div>
</header>

<div class="container">

<?php if ($mensagem): ?>
    <div class="mensagem"><?= e($mensagem) ?></div>
<?php endif; ?>

    <h1>Painel de <span>Administração</span></h1>
    <p>Gerencie os produtos da sua loja MBM.</p>

    <div class="colunas">

        <section class="painel">
            <h2><?= $produtoEdicao ? 'Editar produto' : 'Adicionar produto' ?></h2>

            <form method="POST" enctype="multipart/form-data">

                <input type="hidden" name="acao" value="salvar_produto">
                <input type="hidden" name="id" value="<?= e($produtoEdicao['id'] ?? 0) ?>">
                <input type="hidden" name="imagem_atual" value="<?= e($produtoEdicao['imagem'] ?? '') ?>">

                <label>Nome do produto</label>
                <input type="text" name="nome"
                    value="<?= e($produtoEdicao['nome'] ?? '') ?>" required>

                <label>Descrição</label>
                <textarea name="descricao"><?= e($produtoEdicao['descricao'] ?? '') ?></textarea>

                <label>Preço (R$)</label>
                <input type="number" name="preco" step="0.01" min="0"
                    value="<?= e($produtoEdicao['preco'] ?? '') ?>" required>

                <label>Estoque</label>
                <input type="number" name="estoque" min="0"
                    value="<?= e($produtoEdicao['estoque'] ?? '0') ?>" required>

                <label>Categoria</label>
                <select name="categoria" required>
                    <?php
                    $categorias = [
                        'Whey Protein',
                        'Creatina',
                        'Pré-Treino',
                        'BCAA',
                        'Vitaminas',
                        'Outros'
                    ];
                    ?>
                    <option value="">Selecione</option>

                    <?php foreach ($categorias as $categoria): ?>
                        <option value="<?= e($categoria) ?>"
                            <?= (($produtoEdicao['categoria'] ?? '') === $categoria) ? 'selected' : '' ?>>
                            <?= e($categoria) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label>Imagem do produto</label>
                <input type="file" name="imagem" accept="image/png,image/jpeg,image/webp">

                <?php if (!empty($produtoEdicao['imagem'])): ?>
                    <p style="margin-top:10px">Imagem atual:</p>
                    <img src="<?= e($produtoEdicao['imagem']) ?>"
                         alt="Imagem atual"
                         style="width:90px; height:90px; object-fit:contain; background:white">
                <?php endif; ?>

                <button type="submit">
                    <?= $produtoEdicao ? 'SALVAR ALTERAÇÕES' : 'CADASTRAR PRODUTO' ?>
                </button>

                <?php if ($produtoEdicao): ?>
                    <a class="botao botao-secundario" href="admin.php">Cancelar</a>
                <?php endif; ?>

            </form>
        </section>

        <section class="painel">
            <h2>Resumo da loja</h2>
            <p>Produtos cadastrados: <strong><?= count($produtos) ?></strong></p>
            <p>Administrador conectado: <strong><?= e($_SESSION['admin_nome']) ?></strong></p>
            <p>Use o formulário ao lado para cadastrar novos produtos ou editar os existentes.</p>
        </section>

    </div>

    <section class="painel">
        <h2>Produtos cadastrados</h2>

        <div style="overflow-x:auto">
            <table class="tabela">
                <thead>
                    <tr>
                        <th>Imagem</th>
                        <th>Produto</th>
                        <th>Categoria</th>
                        <th>Preço</th>
                        <th>Estoque</th>
                        <th>Ações</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (count($produtos) === 0): ?>
                    <tr>
                        <td colspan="6">Nenhum produto cadastrado.</td>
                    </tr>
                <?php endif; ?>

                <?php foreach ($produtos as $produto): ?>
                    <tr>
                        <td>
                            <?php if (!empty($produto['imagem'])): ?>
                                <img src="<?= e($produto['imagem']) ?>" alt="">
                            <?php else: ?>
                                Sem imagem
                            <?php endif; ?>
                        </td>

                        <td><?= e($produto['nome']) ?></td>
                        <td><?= e($produto['categoria']) ?></td>
                        <td>R$ <?= number_format((float)$produto['preco'], 2, ',', '.') ?></td>
                        <td><?= e($produto['estoque']) ?></td>

                        <td>
                            <div class="acoes">
                                <a class="botao" href="admin.php?editar=<?= (int)$produto['id'] ?>">
                                    Editar
                                </a>

                                <form method="POST"
                                      onsubmit="return confirm('Deseja realmente excluir este produto?')">
                                    <input type="hidden" name="acao" value="excluir_produto">
                                    <input type="hidden" name="id" value="<?= (int)$produto['id'] ?>">
                                    <button class="botao-excluir" type="submit">Excluir</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>

    <a class="botao botao-secundario" href="loja.php">Voltar para a loja</a>

</div>

</body>
</html>