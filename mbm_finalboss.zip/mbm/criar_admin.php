
<?php
session_start();

require_once __DIR__ . '/config/database.php';

$mensagem = '';
$tipoMensagem = '';

// Verifica se o administrador já está logado
$adminLogado = (
    !empty($_SESSION['admin_id']) &&
    ($_SESSION['tipo_usuario'] ?? '') === 'admin'
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = trim($_POST['nome'] ?? '');
    $usuario = trim($_POST['usuario'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirmarSenha = $_POST['confirmar_senha'] ?? '';

    if ($nome === '' || $usuario === '' || $senha === '') {
        $mensagem = 'Preencha todos os campos.';
        $tipoMensagem = 'erro';

    } elseif (strlen($senha) < 8) {
        $mensagem = 'A senha deve ter pelo menos 8 caracteres.';
        $tipoMensagem = 'erro';

    } elseif ($senha !== $confirmarSenha) {
        $mensagem = 'As senhas não coincidem.';
        $tipoMensagem = 'erro';

    } else {
        try {
            // Verifica se o usuário já existe
            $consulta = $pdo->prepare(
                "SELECT id FROM administradores WHERE usuario = ?"
            );
            $consulta->execute([$usuario]);

            if ($consulta->fetch()) {
                $mensagem = 'Esse usuário já está cadastrado.';
                $tipoMensagem = 'erro';

            } else {
                // Cria o novo administrador
                $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

                $inserir = $pdo->prepare("
                    INSERT INTO administradores
                    (nome, usuario, senha)
                    VALUES (?, ?, ?)
                ");

                $inserir->execute([
                    $nome,
                    $usuario,
                    $senhaHash
                ]);

                $mensagem = 'Administrador cadastrado com sucesso!';
                $tipoMensagem = 'sucesso';
            }

        } catch (PDOException $e) {
            $mensagem = 'Erro ao cadastrar administrador. Verifique a estrutura da tabela.';
            $tipoMensagem = 'erro';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Administrador - MBM</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            min-height: 100vh;
            background: #101010;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            color: white;
        }

        .container {
            background: #1c1c1c;
            width: 100%;
            max-width: 430px;
            padding: 35px;
            border-radius: 15px;
            border: 1px solid #333;
            box-shadow: 0 10px 35px rgba(0,0,0,.4);
        }

        h1 {
            text-align: center;
            margin-bottom: 10px;
            color: #d6ff00;
        }

        .subtitulo {
            text-align: center;
            color: #aaa;
            margin-bottom: 25px;
        }

        label {
            display: block;
            margin: 15px 0 7px;
        }

        input {
            width: 100%;
            padding: 13px;
            border: 1px solid #444;
            border-radius: 7px;
            background: #292929;
            color: white;
            outline: none;
        }

        input:focus {
            border-color: #d6ff00;
        }

        button {
            width: 100%;
            padding: 14px;
            margin-top: 25px;
            background: #d6ff00;
            color: #111;
            border: none;
            border-radius: 7px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
        }

        button:hover {
            background: #c2e600;
        }

        .mensagem {
            padding: 12px;
            border-radius: 7px;
            margin-bottom: 15px;
            text-align: center;
        }

        .sucesso {
            background: #173b20;
            color: #7cff91;
        }

        .erro {
            background: #481d1d;
            color: #ff9999;
        }

        .links {
            text-align: center;
            margin-top: 22px;
        }

        a {
            color: #d6ff00;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>

<div class="container">

    <h1>MBM ADMIN</h1>
    <p class="subtitulo">Cadastro de administrador</p>

    <?php if ($mensagem !== ''): ?>
        <div class="mensagem <?= htmlspecialchars($tipoMensagem) ?>">
            <?= htmlspecialchars($mensagem) ?>
        </div>
    <?php endif; ?>

    <form method="POST" action="">

        <label>Nome completo</label>
        <input
            type="text"
            name="nome"
            required
            placeholder="Digite seu nome"
        >

        <label>Usuário</label>
        <input
            type="text"
            name="usuario"
            required
            placeholder="Crie um nome de usuário"
        >

        <label>Senha</label>
        <input
            type="password"
            name="senha"
            required
            minlength="8"
            placeholder="Mínimo de 8 caracteres"
        >

        <label>Confirmar senha</label>
        <input
            type="password"
            name="confirmar_senha"
            required
            minlength="8"
            placeholder="Digite a senha novamente"
        >

        <button type="submit">CRIAR ADMINISTRADOR</button>

    </form>

    <div class="links">
        <a href="index.php">Voltar para o login</a>
        <br><br>
        <a href="loja.php">Voltar ao início</a>
    </div>

</div>

</body>
</html>
