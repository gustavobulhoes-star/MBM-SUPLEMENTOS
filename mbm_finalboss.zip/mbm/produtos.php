<?php

session_start();

require_once __DIR__ . '/config/database.php';

// Garante que as tabelas favoritos e avaliacoes existem com todas as colunas necessárias
$pdo->exec("
    CREATE TABLE IF NOT EXISTS favoritos (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT UNSIGNED NOT NULL,
        produto_id INT UNSIGNED NOT NULL,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_usuario_produto (usuario_id, produto_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$pdo->exec("
    CREATE TABLE IF NOT EXISTS avaliacoes (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        produto_id INT UNSIGNED NOT NULL,
        usuario_id INT UNSIGNED NOT NULL,
        nota TINYINT UNSIGNED NOT NULL,
        comentario TEXT NOT NULL,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$colunasAvaliacoes = $pdo->query("SHOW COLUMNS FROM avaliacoes")->fetchAll(PDO::FETCH_COLUMN);
if (!in_array('usuario_id', $colunasAvaliacoes)) {
    $pdo->exec("ALTER TABLE avaliacoes ADD COLUMN usuario_id INT UNSIGNED NOT NULL AFTER produto_id");
}
if (!in_array('nota', $colunasAvaliacoes)) {
    $pdo->exec("ALTER TABLE avaliacoes ADD COLUMN nota TINYINT UNSIGNED NOT NULL DEFAULT 5");
}
if (!in_array('comentario', $colunasAvaliacoes)) {
    $pdo->exec("ALTER TABLE avaliacoes ADD COLUMN comentario TEXT NOT NULL");
}
if (!in_array('criado_em', $colunasAvaliacoes)) {
    $pdo->exec("ALTER TABLE avaliacoes ADD COLUMN criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP");
}
if (in_array('nome', $colunasAvaliacoes)) {
    $pdo->exec("ALTER TABLE avaliacoes MODIFY COLUMN nome VARCHAR(150) NULL DEFAULT NULL");
}

$arquivoImagens = __DIR__ . '/config/imagens-produtos.php';
$imagensProdutos = file_exists($arquivoImagens) ? require $arquivoImagens : [];

function e($valor): string {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

if (!isset($_SESSION['carrinho']) || !is_array($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

$usuarioIdSessao = (int)($_SESSION['usuario_id'] ?? 0);
$produtoDetalheId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

// Favoritos do usuário
$favoritosUsuario = [];
if ($usuarioIdSessao > 0) {
    $stmtFavs = $pdo->prepare('SELECT produto_id FROM favoritos WHERE usuario_id = ?');
    $stmtFavs->execute([$usuarioIdSessao]);
    $favoritosUsuario = array_column($stmtFavs->fetchAll(PDO::FETCH_ASSOC), 'produto_id');
}

$mensagemErro = '';
$mensagemSucesso = '';

// PROCESSAR AÇÕES POST (Carrinho ou Avaliação)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'adicionar') {
        $produtoId = filter_input(INPUT_POST, 'produto_id', FILTER_VALIDATE_INT);
        $qtd = max(1, (int)($_POST['quantidade'] ?? 1));

        if ($produtoId) {
            $stmt = $pdo->prepare("SELECT id, estoque FROM produtos WHERE id = ? AND ativo = 1 LIMIT 1");
            $stmt->execute([$produtoId]);
            $prod = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($prod && (int)$prod['estoque'] >= ((int)($_SESSION['carrinho'][$produtoId] ?? 0) + $qtd)) {
                $_SESSION['carrinho'][$produtoId] = (int)($_SESSION['carrinho'][$produtoId] ?? 0) + $qtd;
                header('Location: carrinho.php');
                exit;
            } else {
                $mensagemErro = 'Quantidade indisponível em estoque.';
            }
        }
    }

    if ($acao === 'avaliar' && $produtoDetalheId) {
        if ($usuarioIdSessao <= 0) {
            header('Location: index.php?modo=login');
            exit;
        }

        $nota = filter_input(INPUT_POST, 'nota', FILTER_VALIDATE_INT);
        $comentario = trim((string)($_POST['comentario'] ?? ''));

        if ($nota < 1 || $nota > 5) {
            $mensagemErro = 'Selecione uma nota entre 1 e 5 estrelas.';
        } elseif (mb_strlen($comentario) < 3) {
            $mensagemErro = 'Escreva um comentário válido sobre o produto.';
        } else {
            try {
                $stmtNome = $pdo->prepare('SELECT nome FROM usuarios WHERE id = ? LIMIT 1');
                $stmtNome->execute([$usuarioIdSessao]);
                $nomeAutor = $stmtNome->fetchColumn() ?: 'Cliente MBM';

                if (in_array('nome', $colunasAvaliacoes)) {
                    $stmtAval = $pdo->prepare('
                        INSERT INTO avaliacoes (produto_id, usuario_id, nome, nota, comentario)
                        VALUES (?, ?, ?, ?, ?)
                    ');
                    $stmtAval->execute([$produtoDetalheId, $usuarioIdSessao, $nomeAutor, $nota, $comentario]);
                } else {
                    $stmtAval = $pdo->prepare('
                        INSERT INTO avaliacoes (produto_id, usuario_id, nota, comentario)
                        VALUES (?, ?, ?, ?)
                    ');
                    $stmtAval->execute([$produtoDetalheId, $usuarioIdSessao, $nota, $comentario]);
                }

                header('Location: produtos.php?id=' . $produtoDetalheId . '&avaliado=1#avaliacoes');
                exit;
            } catch (PDOException $e) {
                $mensagemErro = 'Erro ao salvar avaliação: ' . $e->getMessage();
            }
        }
    }
}

if (isset($_GET['avaliado'])) {
    $mensagemSucesso = 'Avaliação enviada com sucesso! Obrigado pelo seu feedback.';
}

function imagemDoProduto(array $produto, array $imagens): string {
    $nome = mb_strtolower(trim($produto['nome']), 'UTF-8');
    foreach ($imagens as $termo => $caminho) {
        if (mb_strpos($nome, mb_strtolower($termo, 'UTF-8')) !== false) {
            return $caminho;
        }
    }
    return trim((string)($produto['imagem'] ?? ''));
}

// SE TIVER ?id=X NA URL, BUSCA O PRODUTO ÚNICO PARA EXIBIR DETALHES E AVALIAÇÕES
$produtoUnico = null;
$avaliacoes = [];
$mediaNota = 0;
$totalAvaliacoes = 0;

if ($produtoDetalheId) {
    $stmtProd = $pdo->prepare('SELECT * FROM produtos WHERE id = ? AND ativo = 1 LIMIT 1');
    $stmtProd->execute([$produtoDetalheId]);
    $produtoUnico = $stmtProd->fetch(PDO::FETCH_ASSOC);

    if ($produtoUnico) {
        $stmtAvaliacoes = $pdo->prepare('
            SELECT a.nota, a.comentario, a.criado_em, COALESCE(u.nome, "Cliente MBM") AS usuario_nome
            FROM avaliacoes a
            LEFT JOIN usuarios u ON u.id = a.usuario_id
            WHERE a.produto_id = ?
            ORDER BY a.criado_em DESC
        ');
        $stmtAvaliacoes->execute([$produtoDetalheId]);
        $avaliacoes = $stmtAvaliacoes->fetchAll(PDO::FETCH_ASSOC);

        $totalAvaliacoes = count($avaliacoes);
        if ($totalAvaliacoes > 0) {
            $mediaNota = round(array_sum(array_column($avaliacoes, 'nota')) / $totalAvaliacoes, 1);
        }
    }
}

// CASO NÃO SEJA DETALHE, CARREGA O CATÁLOGO NORMAL
$mapaCategorias = [
    'proteinas' => ['proteina', 'proteína', 'whey'],
    'veganos' => ['vegano', 'vegan'],
    'vegetarianos' => ['vegetariano'],
    'termogenicos' => ['termogenico', 'termogênico', 'cafeina', 'cafeína', 'pré-treino'],
    'vitaminas' => ['vitamina', 'multivitaminico', 'multivitamínico', 'biotina'],
    'linha-clinical' => ['clinical', 'testo', 'booster'],
    'aminoacidos' => ['aminoacido', 'aminoácido', 'bcaa'],
    'creatina' => ['creatina'],
    'carboidratos' => ['carboidrato', 'maltodextrina', 'hipercalorico', 'hipercalórico'],
    'acessorios' => ['bolsa', 'coqueteleira'],
    'roupas' => ['camiseta', 'bermuda']
];

$categoria = trim((string)($_GET['categoria'] ?? ''));
$busca = trim((string)($_GET['busca'] ?? ''));
$produtos = [];

if (!$produtoUnico) {
    $where = ['p.ativo = 1'];
    $params = [];

    if (isset($mapaCategorias[$categoria])) {
        $partes = [];
        foreach ($mapaCategorias[$categoria] as $termo) {
            $partes[] = '(LOWER(p.categoria) LIKE ? OR LOWER(p.nome) LIKE ?)';
            $like = '%' . mb_strtolower($termo, 'UTF-8') . '%';
            $params[] = $like;
            $params[] = $like;
        }
        $where[] = '(' . implode(' OR ', $partes) . ')';
    }

    if ($busca !== '') {
        $where[] = "(LOWER(p.nome) LIKE ? OR LOWER(p.descricao) LIKE ? OR LOWER(p.categoria) LIKE ?)";
        $like = '%' . mb_strtolower($busca, 'UTF-8') . '%';
        array_push($params, $like, $like, $like);
    }

    $sql = "
        SELECT
            p.id, p.nome, p.descricao, p.preco, p.estoque, p.categoria, p.imagem,
            COALESCE(AVG(a.nota), 0) AS media_nota,
            COUNT(a.id) AS total_avaliacoes
        FROM produtos p
        LEFT JOIN avaliacoes a ON a.produto_id = p.id
        WHERE " . implode(' AND ', $where) . "
        GROUP BY p.id
        ORDER BY p.id DESC
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

$quantidadeCarrinho = array_sum(array_map('intval', $_SESSION['carrinho']));

$titulo = $produtoUnico
    ? $produtoUnico['nome']
    : (isset($mapaCategorias[$categoria])
        ? 'Categoria: ' . ucfirst(str_replace('-', ' ', $categoria))
        : ($busca !== '' ? 'Busca: ' . $busca : 'Todos os produtos'));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e($titulo) ?> | MBM Suplementos</title>
<style>
:root {
    --red: #ed101b;
    --red2: #ff3039;
    --bg: #070708;
    --panel: #121214;
    --line: #29292e;
    --muted: #999;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: Arial, Helvetica, sans-serif; background: var(--bg); color: #fff; }
a { color: inherit; text-decoration: none; }

.header {
    height: 76px; background: #060607; border-bottom: 1px solid var(--line);
    display: flex; align-items: center; position: sticky; top: 0; z-index: 50;
}
.header-inner {
    width: min(1250px, 92%); margin: auto; display: flex;
    align-items: center; justify-content: space-between; gap: 20px;
}
.logo img { width: 145px; max-height: 55px; object-fit: contain; }
nav { display: flex; align-items: center; gap: 25px; font-size: 13px; font-weight: 800; }
nav a:hover { color: var(--red); }
.cart { background: var(--red); padding: 11px 15px; border-radius: 7px; }

.page { width: min(1250px, 92%); margin: auto; padding: 50px 0 90px; }
.kicker { color: var(--red); font-size: 11px; font-weight: 900; letter-spacing: 3px; }
.heading {
    display: flex; justify-content: space-between; align-items: end;
    margin: 10px 0 30px; gap: 15px;
}
.heading h1 { font-size: clamp(30px, 4vw, 42px); }
.heading p { color: var(--muted); font-size: 13px; margin-top: 8px; }
.heading a { color: var(--red); font-size: 12px; font-weight: 800; }

/* GRID DE CATÁLOGO */
.grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 18px; }
.card {
    background: linear-gradient(145deg, #19191c, #0d0d0f);
    border: 1px solid var(--line); border-radius: 12px;
    overflow: hidden; transition: .25s; position: relative;
    cursor: pointer;
}
.card:hover { border-color: var(--red); transform: translateY(-4px); }

.fav-btn {
    position: absolute; top: 12px; right: 12px; width: 36px; height: 36px;
    border-radius: 50%; border: 1px solid #303035; background: rgba(15, 15, 18, 0.92);
    color: #fff; font-size: 18px; cursor: pointer; display: grid; place-items: center;
    z-index: 10; transition: .2s;
}
.fav-btn:hover { border-color: var(--red); transform: scale(1.1); }
.fav-btn.active { background: var(--red); border-color: var(--red); color: #fff; }

.photo {
    height: 260px; display: flex; align-items: center; justify-content: center;
    padding: 10px; background: radial-gradient(ellipse, #29292d, transparent 72%);
}
.photo img {
    width: 100%; height: 100%; object-fit: contain; transition: .3s;
    filter: drop-shadow(0 10px 15px #000);
}
.card:hover .photo img { transform: scale(1.04); }

.info { padding: 17px; }
.category { font-size: 10px; color: var(--red); font-weight: 900; letter-spacing: 1.5px; text-transform: uppercase; }
.name { font-size: 17px; font-weight: 900; line-height: 1.4; margin: 8px 0 4px; }
.card:hover .name { color: var(--red); }
.rating-mini { font-size: 13px; color: #ffb400; margin-bottom: 8px; }
.rating-mini span { color: #888; font-size: 11px; }
.desc { font-size: 11px; line-height: 1.5; color: #888; min-height: 34px; }
.price { font-size: 22px; font-weight: 900; color: var(--red); margin: 14px 0; }
.stock { color: #999; font-size: 10px; margin-bottom: 12px; }

.buy {
    width: 100%; border: 0; border-radius: 7px; padding: 12px;
    background: var(--red); color: #fff; font-size: 11px;
    font-weight: 900; cursor: pointer; transition: .2s;
    position: relative; z-index: 5;
}
.buy:hover { background: var(--red2); transform: translateY(-2px); }
.buy:disabled { background: #444; cursor: not-allowed; transform: none; }

/* PÁGINA DE DETALHE DO PRODUTO */
.breadcrumb { font-size: 12px; color: var(--muted); margin-bottom: 25px; }
.breadcrumb a:hover { color: var(--red); }

.product-detail {
    display: grid; grid-template-columns: 1fr 1.1fr; gap: 45px;
    background: var(--panel); border: 1px solid var(--line);
    border-radius: 16px; padding: 35px;
}
.product-gallery {
    background: radial-gradient(circle, #242429, #0e0e10 75%);
    border-radius: 12px; display: flex; align-items: center;
    justify-content: center; min-height: 360px; padding: 25px; position: relative;
}
.product-gallery img {
    max-width: 100%; max-height: 350px; object-fit: contain;
    filter: drop-shadow(0 15px 25px rgba(0,0,0,.8));
}
.detail-title { font-size: 30px; font-weight: 900; margin: 8px 0 12px; line-height: 1.2; }
.detail-price { font-size: 34px; font-weight: 900; color: var(--red); margin: 18px 0; }
.detail-desc {
    color: #b5b5bd; font-size: 14px; line-height: 1.7;
    margin-bottom: 25px; border-top: 1px solid var(--line); padding-top: 18px;
}
.actions-row { display: flex; gap: 12px; align-items: center; }
.qty-input {
    width: 75px; height: 48px; background: #0a0a0c; border: 1px solid var(--line);
    border-radius: 8px; color: #fff; text-align: center; font-size: 15px; font-weight: 700;
}
.btn-buy-lg {
    flex: 1; height: 48px; background: var(--red); border: 0; border-radius: 8px;
    color: #fff; font-weight: 900; font-size: 13px; cursor: pointer; transition: .2s;
}
.btn-buy-lg:hover { background: var(--red2); }
.btn-buy-lg:disabled { background: #444; cursor: not-allowed; }

/* AVALIAÇÕES */
.reviews-section {
    margin-top: 40px; background: var(--panel); border: 1px solid var(--line);
    border-radius: 16px; padding: 35px;
}
.reviews-header {
    border-bottom: 1px solid var(--line); padding-bottom: 16px; margin-bottom: 25px;
}
.review-form {
    background: #0b0b0d; border: 1px solid var(--line);
    border-radius: 12px; padding: 22px; margin-bottom: 30px;
}
.review-form h3 { font-size: 15px; margin-bottom: 14px; }
.star-select { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 14px; }
.star-select label { cursor: pointer; font-size: 13px; background: #18181d; padding: 8px 12px; border-radius: 6px; border: 1px solid var(--line); }
.star-select input { margin-right: 5px; accent-color: var(--red); }
.review-form textarea {
    width: 100%; min-height: 95px; background: #141418; border: 1px solid var(--line);
    border-radius: 8px; color: #fff; padding: 12px; font-family: inherit;
    font-size: 13px; resize: vertical; margin-bottom: 14px;
}
.btn-submit-review {
    background: var(--red); color: #fff; border: 0; padding: 12px 22px;
    border-radius: 7px; font-weight: 800; font-size: 12px; cursor: pointer;
}
.review-list { display: flex; flex-direction: column; gap: 16px; }
.review-item { border-bottom: 1px solid var(--line); padding-bottom: 16px; }
.review-item:last-child { border-bottom: 0; padding-bottom: 0; }
.review-top { display: flex; justify-content: space-between; margin-bottom: 6px; font-size: 13px; }
.review-date { color: var(--muted); font-size: 11px; }
.review-text { color: #ccc; font-size: 13px; line-height: 1.6; }

.alert { padding: 12px 16px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
.alert-err { background: #3b1215; border: 1px solid var(--red); color: #ff8a90; }
.alert-ok { background: #11331d; border: 1px solid #22c55e; color: #86efac; }
.empty { padding: 45px; text-align: center; border: 1px solid var(--line); border-radius: 12px; color: #999; grid-column: 1 / -1; }

footer { text-align: center; padding: 30px; color: #777; border-top: 1px solid var(--line); font-size: 12px; }
footer strong { color: var(--red); }

@media(max-width: 950px) {
    .grid { grid-template-columns: repeat(2, 1fr); }
    .product-detail { grid-template-columns: 1fr; padding: 22px; }
}
@media(max-width: 600px) {
    .header { height: auto; padding: 14px 0; }
    .header-inner { flex-wrap: wrap; }
    .logo img { width: 115px; }
    nav { gap: 15px; font-size: 11px; flex-wrap: wrap; }
    .grid { grid-template-columns: 1fr; }
    .heading { display: block; }
}
</style>
</head>
<body>

<header class="header">
    <div class="header-inner">
        <a class="logo" href="loja.php">
            <img src="img/mbm logo sem fundo.png" alt="MBM Suplementos">
        </a>
        <nav>
            <a href="loja.php">Início</a>
            <a href="produtos.php">Produtos</a>
            <a href="favoritar/favoritos.php">Favoritos</a>
            <a href="index.php">Entrar</a>
            <a class="cart" href="carrinho.php">🛒 Carrinho (<?= $quantidadeCarrinho ?>)</a>
        </nav>
    </div>
</header>

<main class="page">

    <?php if ($mensagemErro): ?>
        <div class="alert alert-err"><?= e($mensagemErro) ?></div>
    <?php endif; ?>

    <?php if ($mensagemSucesso): ?>
        <div class="alert alert-ok"><?= e($mensagemSucesso) ?></div>
    <?php endif; ?>

    <?php if ($produtoUnico): ?>
        <?php
        $imgDetalhe = imagemDoProduto($produtoUnico, $imagensProdutos);
        $semEstoqueDetalhe = (int)$produtoUnico['estoque'] <= 0;
        $isFavDetalhe = in_array($produtoUnico['id'], $favoritosUsuario);
        ?>

        <div class="breadcrumb">
            <a href="loja.php">Início</a> / <a href="produtos.php">Produtos</a> / <span><?= e($produtoUnico['nome']) ?></span>
        </div>

        <section class="product-detail">
            <div class="product-gallery">
                <button type="button"
                        class="fav-btn <?= $isFavDetalhe ? 'active' : '' ?>"
                        onclick="toggleFavorito(<?= (int)$produtoUnico['id'] ?>, this)"
                        title="<?= $isFavDetalhe ? 'Remover dos favoritos' : 'Adicionar aos favoritos' ?>">
                    <?= $isFavDetalhe ? '♥' : '♡' ?>
                </button>

                <?php if ($imgDetalhe !== ''): ?>
                    <img src="<?= e($imgDetalhe) ?>" alt="<?= e($produtoUnico['nome']) ?>">
                <?php else: ?>
                    <span style="font-size: 80px;">🥤</span>
                <?php endif; ?>
            </div>

            <div>
                <div class="category"><?= e($produtoUnico['categoria'] ?? 'Suplemento') ?></div>
                <h1 class="detail-title"><?= e($produtoUnico['nome']) ?></h1>

                <div class="rating-mini">
                    <?= str_repeat('★', (int)round($mediaNota)) . str_repeat('☆', 5 - (int)round($mediaNota)) ?>
                    <span><strong><?= number_format($mediaNota, 1, ',', '.') ?></strong> (<?= $totalAvaliacoes ?> <?= $totalAvaliacoes === 1 ? 'avaliação' : 'avaliações' ?>)</span>
                </div>

                <div class="detail-price">
                    R$ <?= number_format((float)$produtoUnico['preco'], 2, ',', '.') ?>
                </div>

                <div class="stock" style="font-size: 12px; color: <?= $semEstoqueDetalhe ? '#ff5555' : '#4ade80' ?>;">
                    <?= $semEstoqueDetalhe ? '● Produto esgotado no momento' : '● Em estoque (' . (int)$produtoUnico['estoque'] . ' unidades disponíveis)' ?>
                </div>

                <p class="detail-desc">
                    <?= nl2br(e($produtoUnico['descricao'] ?: 'Suplemento de alta qualidade MBM para potencializar seus treinos e resultados.')) ?>
                </p>

                <form method="post" class="actions-row">
                    <input type="hidden" name="acao" value="adicionar">
                    <input type="hidden" name="produto_id" value="<?= (int)$produtoUnico['id'] ?>">
                    <input type="number" name="quantidade" value="1" min="1" max="<?= max(1, (int)$produtoUnico['estoque']) ?>" class="qty-input" <?= $semEstoqueDetalhe ? 'disabled' : '' ?>>
                    <button type="submit" class="btn-buy-lg" <?= $semEstoqueDetalhe ? 'disabled' : '' ?>>
                        🛒 <?= $semEstoqueDetalhe ? 'INDISPONÍVEL' : 'ADICIONAR AO CARRINHO' ?>
                    </button>
                </form>
            </div>
        </section>

        <section class="reviews-section" id="avaliacoes">
            <div class="reviews-header">
                <h2>Avaliações dos Clientes (<?= $totalAvaliacoes ?>)</h2>
            </div>

            <?php if ($usuarioIdSessao > 0): ?>
                <form method="post" class="review-form">
                    <input type="hidden" name="acao" value="avaliar">
                    <h3>Deixe sua avaliação</h3>
                    <div class="star-select">
                        <?php for ($i = 5; $i >= 1; $i--): ?>
                            <label>
                                <input type="radio" name="nota" value="<?= $i ?>" <?= $i === 5 ? 'checked' : '' ?>>
                                <?= $i ?> ★
                            </label>
                        <?php endfor; ?>
                    </div>
                    <textarea name="comentario" placeholder="Conte o que achou da qualidade, sabor e resultados..." required></textarea>
                    <button type="submit" class="btn-submit-review">PUBLICAR AVALIAÇÃO</button>
                </form>
            <?php else: ?>
                <div class="review-form">
                    <p style="font-size: 13px; color: #bbb;">
                        Quer avaliar este produto? <a href="index.php?modo=login" style="color: var(--red); font-weight: 700;">Faça login na sua conta</a>.
                    </p>
                </div>
            <?php endif; ?>

            <div class="review-list">
                <?php if (!$avaliacoes): ?>
                    <p style="color: var(--muted); font-size: 13px;">Este produto ainda não possui avaliações. Seja o primeiro a avaliar!</p>
                <?php else: ?>
                    <?php foreach ($avaliacoes as $av): ?>
                        <div class="review-item">
                            <div class="review-top">
                                <div>
                                    <strong><?= e($av['usuario_nome']) ?></strong>
                                    <span style="color: #ffb400; margin-left: 8px;">
                                        <?= str_repeat('★', (int)$av['nota']) . str_repeat('☆', 5 - (int)$av['nota']) ?>
                                    </span>
                                </div>
                                <span class="review-date"><?= date('d/m/Y H:i', strtotime($av['criado_em'])) ?></span>
                            </div>
                            <p class="review-text"><?= nl2br(e($av['comentario'])) ?></p>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>

    <?php else: ?>
        <div class="kicker">CONHEÇA NOSSA LINHA</div>

        <div class="heading">
            <div>
                <h1><?= e($titulo) ?></h1>
                <p>Suplementos para performance, força e evolução.</p>
            </div>
            <a href="loja.php">← Voltar ao início</a>
        </div>

        <div class="grid">
            <?php if (!$produtos): ?>
                <div class="empty">
                    Nenhum produto encontrado nesta categoria. Confira os produtos disponíveis na loja.
                </div>
            <?php endif; ?>

            <?php foreach ($produtos as $produto): ?>
                <?php
                $img = imagemDoProduto($produto, $imagensProdutos);
                $semEstoque = (int)$produto['estoque'] <= 0;
                $isFav = in_array($produto['id'], $favoritosUsuario);
                $linkProduto = 'produtos.php?id=' . (int)$produto['id'];
                $media = round((float)$produto['media_nota']);
                ?>

                <article class="card" onclick="window.location.href='<?= $linkProduto ?>'">
                    <button type="button"
                            class="fav-btn <?= $isFav ? 'active' : '' ?>"
                            onclick="event.stopPropagation(); toggleFavorito(<?= (int)$produto['id'] ?>, this)"
                            title="<?= $isFav ? 'Remover dos favoritos' : 'Adicionar aos favoritos' ?>">
                        <?= $isFav ? '♥' : '♡' ?>
                    </button>

                    <div class="photo">
                        <?php if ($img !== ''): ?>
                            <img src="<?= e($img) ?>" alt="<?= e($produto['nome']) ?>" loading="lazy">
                        <?php else: ?>
                            <span style="font-size:48px">🥤</span>
                        <?php endif; ?>
                    </div>

                    <div class="info">
                        <div class="category"><?= e($produto['categoria'] ?? 'Suplemento') ?></div>

                        <div class="name">
                            <a href="<?= $linkProduto ?>"><?= e($produto['nome']) ?></a>
                        </div>

                        <div class="rating-mini">
                            <?= str_repeat('★', (int)$media) . str_repeat('☆', 5 - (int)$media) ?>
                            <span>(<?= (int)$produto['total_avaliacoes'] ?>)</span>
                        </div>

                        <p class="desc"><?= e($produto['descricao'] ?? '') ?></p>

                        <div class="price">
                            R$ <?= number_format((float)$produto['preco'], 2, ',', '.') ?>
                        </div>

                        <div class="stock">
                            <?= $semEstoque ? 'Produto indisponível' : 'Disponível em estoque' ?>
                        </div>

                        <form method="post" onclick="event.stopPropagation()">
                            <input type="hidden" name="acao" value="adicionar">
                            <input type="hidden" name="produto_id" value="<?= (int)$produto['id'] ?>">
                            <button class="buy" type="submit" <?= $semEstoque ? 'disabled' : '' ?>>
                                🛒 <?= $semEstoque ? 'SEM ESTOQUE' : 'ADICIONAR AO CARRINHO' ?>
                            </button>
                        </form>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

</main>

<footer>
    <strong>MBM SUPLEMENTOS</strong>
    <p>Performance • Força • Resultado</p>
    <p>© <?= date('Y') ?> MBM Suplementos. Todos os direitos reservados.</p>
</footer>

<script>
function toggleFavorito(produtoId, btn) {
    const formData = new FormData();
    formData.append('produto_id', produtoId);

    fetch('favoritar/favoritar.php', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === 'nao_logado') {
            window.location.href = data.redirect;
        } else if (data.status === 'ok') {
            btn.classList.toggle('active', data.favoritado);
            btn.textContent = data.favoritado ? '♥' : '♡';
        }
    });
}
</script>

</body>
</html>