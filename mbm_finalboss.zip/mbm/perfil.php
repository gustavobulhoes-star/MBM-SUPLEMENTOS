
<?php
session_start();

require_once __DIR__ . '/config/database.php';

if (empty($_SESSION['usuario_id'])) {
    header('Location: index.php?modo=login');
    exit;
}

$id = (int) $_SESSION['usuario_id'];

$stmt = $pdo->prepare("
    SELECT id, nome, email, foto_perfil
    FROM usuarios
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([$id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$usuario) {
    session_destroy();
    header('Location: index.php');
    exit;
}

$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nome = trim($_POST['nome'] ?? '');

    if ($nome === '') {
        $erro = 'Informe seu nome.';
    } else {

        $foto = $usuario['foto_perfil'];

        if (
            isset($_FILES['foto']) &&
            $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE
        ) {

            if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
                $erro = 'Erro ao enviar a imagem.';
            } elseif ($_FILES['foto']['size'] > 2 * 1024 * 1024) {
                $erro = 'A imagem deve ter no máximo 2 MB.';
            } else {

                $info = @getimagesize($_FILES['foto']['tmp_name']);

                $tipos = [
                    'image/jpeg' => 'jpg',
                    'image/png' => 'png',
                    'image/webp' => 'webp'
                ];

                $mime = $info['mime'] ?? '';

                if (!$info || !isset($tipos[$mime])) {
                    $erro = 'Envie uma imagem JPG, PNG ou WEBP.';
                } else {

                    $pasta = __DIR__ . '/uploads/perfis/';

                    if (!is_dir($pasta)) {
                        mkdir($pasta, 0755, true);
                    }

                    $novoNome = bin2hex(random_bytes(16))
                        . '.' . $tipos[$mime];

                    if (move_uploaded_file(
                        $_FILES['foto']['tmp_name'],
                        $pasta . $novoNome
                    )) {

                        if (!empty($foto)) {
                            $antiga = $pasta . basename($foto);

                            if (is_file($antiga)) {
                                unlink($antiga);
                            }
                        }

                        $foto = $novoNome;

                    } else {
                        $erro = 'Não foi possível salvar a imagem.';
                    }
                }
            }
        }

        if ($erro === '') {

            $stmt = $pdo->prepare("
                UPDATE usuarios
                SET nome = ?, foto_perfil = ?
                WHERE id = ?
            ");

            $stmt->execute([$nome, $foto, $id]);

            $_SESSION['usuario_nome'] = $nome;

            $sucesso = 'Perfil atualizado com sucesso!';

            $usuario['nome'] = $nome;
            $usuario['foto_perfil'] = $foto;
        }
    }
}

$fotoUrl = !empty($usuario['foto_perfil'])
    ? 'uploads/perfis/' . rawurlencode($usuario['foto_perfil'])
    : '';
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Minha conta | MBM Suplementos</title>

<style>
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    background: #09090b;
    color: white;
    font-family: 'Poppins', Arial, sans-serif;
    min-height: 100vh;
    padding: 40px 20px;
}

.container {
    width: min(650px, 100%);
    margin: 30px auto;
    background: #141416;
    border: 1px solid #29292e;
    border-radius: 16px;
    padding: 35px;
}

.logo {
    text-align: center;
    color: #ed101b;
    font-size: 24px;
    font-weight: 900;
    margin-bottom: 30px;
}

h1 {
    font-size: 25px;
    margin-bottom: 8px;
}

.subtitle {
    color: #999;
    font-size: 13px;
    margin-bottom: 30px;
}

.avatar {
    width: 125px;
    height: 125px;
    border-radius: 50%;
    border: 3px solid #ed101b;
    object-fit: cover;
    background: #222;
    display: block;
    margin: 0 auto 15px;
}

.avatar-placeholder {
    display: grid;
    place-items: center;
    font-size: 48px;
    color: #999;
}

.upload {
    display: block;
    text-align: center;
    color: #ff3039;
    cursor: pointer;
    font-size: 13px;
    margin-bottom: 30px;
}

.upload input {
    display: none;
}

label {
    display: block;
    font-size: 11px;
    font-weight: bold;
    margin: 18px 0 8px;
    color: #aaa;
}

input[type="text"] {
    width: 100%;
    padding: 14px;
    border-radius: 8px;
    border: 1px solid #333;
    background: #0c0c0e;
    color: white;
    outline: none;
}

input:focus {
    border-color: #ed101b;
}

.email {
    padding: 14px;
    background: #0c0c0e;
    border: 1px solid #333;
    border-radius: 8px;
    color: #888;
}

button {
    width: 100%;
    margin-top: 25px;
    padding: 15px;
    background: #ed101b;
    color: white;
    border: none;
    border-radius: 8px;
    font-weight: bold;
    cursor: pointer;
}

button:hover {
    background: #ff3039;
}

.message {
    padding: 13px;
    margin-bottom: 20px;
    border-radius: 8px;
    font-size: 13px;
}

.error {
    background: #451919;
    color: #ff7777;
}

.success {
    background: #14351e;
    color: #75e995;
}

.back {
    display: block;
    text-align: center;
    margin-top: 25px;
    color: #aaa;
    text-decoration: none;
    font-size: 13px;
}

.back:hover {
    color: #ed101b;
}

</style>
</head>

<body>

<div class="container">

    <div class="logo">MBM SUPLEMENTOS</div>

    <h1>Minha conta</h1>
    <p class="subtitle">Gerencie suas informações pessoais.</p>

    <?php if ($erro): ?>
        <div class="message error">
            <?= htmlspecialchars($erro) ?>
        </div>
    <?php endif; ?>

    <?php if ($sucesso): ?>
        <div class="message success">
            <?= htmlspecialchars($sucesso) ?>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">

        <?php if ($fotoUrl): ?>
            <img class="avatar" src="<?= htmlspecialchars($fotoUrl) ?>"
                 alt="Foto de perfil">
        <?php else: ?>
            <div class="avatar avatar-placeholder">👤</div>
        <?php endif; ?>

        <label class="upload">
            + Alterar foto de perfil
            <input type="file" name="foto"
                   accept="image/jpeg,image/png,image/webp">
        </label>

        <label>NOME COMPLETO</label>
        <input type="text" name="nome"
               value="<?= htmlspecialchars($usuario['nome']) ?>"
               maxlength="150" required>

        <label>E-MAIL</label>
        <div class="email">
            <?= htmlspecialchars($usuario['email']) ?>
        </div>

        <button type="submit">
            SALVAR ALTERAÇÕES
        </button>

    </form>

    <a href="loja.php" class="back">
        ← Voltar para a loja
    </a>

</div>

</body>
</html>
