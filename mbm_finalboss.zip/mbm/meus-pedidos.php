<?php
session_start();
require_once __DIR__ . '/config/database.php';
if (empty($_SESSION['usuario_id'])) { header('Location: index.php?modo=login'); exit; }
$usuarioId = (int)$_SESSION['usuario_id'];
$stmt = $pdo->prepare('SELECT id, total, status, pagamento, criado_em FROM pedidos WHERE usuario_id = ? ORDER BY criado_em DESC');
$stmt->execute([$usuarioId]);
$pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
function e($v) { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function statusPedido($s) {
    $nomes = ['aguardando_pagamento'=>'Aguardando pagamento','pago'=>'Pago','enviado'=>'Enviado','entregue'=>'Entregue','cancelado'=>'Cancelado'];
    return $nomes[$s] ?? $s;
}
?>
<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Meus pedidos | MBM Suplementos</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#080809;color:#fff;font-family:Arial,sans-serif}
header{padding:24px 4%;background:#050506;border-bottom:1px solid #29292e}a{color:#fff;text-decoration:none}
main{width:min(950px,92%);margin:40px auto}h1{margin:0 0 8px}.muted{color:#999;font-size:14px}
.card{background:#131315;border:1px solid #303035;border-radius:12px;padding:18px;margin-top:14px;display:flex;justify-content:space-between;gap:15px;flex-wrap:wrap}
small{color:#999}.price{color:#ff3039;font-size:18px;font-weight:bold}.empty{padding:30px;text-align:center;background:#131315;border:1px solid #303035;border-radius:12px;margin-top:20px}
</style></head><body>
<header><a href="loja.php">← VOLTAR PARA A LOJA</a></header>
<main><h1>Meus pedidos</h1><p class="muted">Histórico de compras realizadas na MBM Suplementos.</p>
<?php if(!$pedidos): ?><div class="empty">Você ainda não possui pedidos.<br><br><a href="produtos.php">Conhecer produtos →</a></div>
<?php else: foreach($pedidos as $pedido): ?>
<div class="card"><div><b>Pedido #<?= (int)$pedido['id'] ?></b><br><small><?=e(date('d/m/Y H:i',strtotime($pedido['criado_em'])))?></small><br><small><?=e(statusPedido($pedido['status']))?> · <?=e($pedido['pagamento'])?></small></div>
<div class="price">R$ <?=number_format((float)$pedido['total'],2,',','.')?></div></div>
<?php endforeach; endif; ?>
</main></body></html>