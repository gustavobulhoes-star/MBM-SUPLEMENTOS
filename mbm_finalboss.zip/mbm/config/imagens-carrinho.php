
<?php

return [

    'proteina vegana' => 'img/vegan.png',

    'whey protein' => 'img/proteinas.jpg',

    'bcaa' => 'img/bcaa.png',

    'pré-treino' => 'img/pre-treino.jpeg',

    'creatina' => 'img/creatina.jpeg',

];
