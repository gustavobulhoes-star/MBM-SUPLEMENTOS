
<?php

return [

    // Proteínas
    'proteina vegana' => 'img/vegan.png',
    'whey protein' => 'img/proteinas.jpg',

    // Aminoácidos
    'bcaa' => 'img/bcaa.png',

    // Pré-treino
    'pré-treino' => 'img/pre-treino.jpeg',

    // Creatina
    'creatina' => 'img/creatina.jpeg',

    'proteina vegana' => 'img/vegan.png',

    'bcaa' => 'img/bcaa.png',

    'pré-treino' => 'img/pre-treino.jpeg',

    'creatina' => 'img/creatina.jpeg',

    'whey protein' => 'img/proteinas.jpg',

];
