<?php

session_start();

require_once __DIR__ . '/config/database.php';

$pdo->exec("
    CREATE TABLE IF NOT EXISTS favoritos (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        usuario_id INT UNSIGNED NOT NULL,
        produto_id INT UNSIGNED NOT NULL,
        criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uk_usuario_produto (usuario_id, produto_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
");

$isAdmin = false;

if (
    !empty($_SESSION['admin_id']) &&
    (($_SESSION['tipo_usuario'] ?? '') === 'admin')
) {
    $stmtCheckAdmin = $pdo->prepare('SELECT id FROM administradores WHERE id = ? LIMIT 1');
    $stmtCheckAdmin->execute([(int)$_SESSION['admin_id']]);

    if ($stmtCheckAdmin->fetch()) {
        $isAdmin = true;
    } else {
        unset($_SESSION['admin_id'], $_SESSION['admin_nome'], $_SESSION['admin_email']);
    }
}

if (!isset($_SESSION['carrinho']) || !is_array($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

$isAdmin = !empty($_SESSION['admin_id']) || (($_SESSION['tipo_usuario'] ?? '') === 'admin');

function e($valor): string {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

$usuarioLogado = null;
$usuarioIdSessao = (int)($_SESSION['usuario_id'] ?? 0);

if ($usuarioIdSessao > 0) {
    $stmtUsuario = $pdo->prepare('SELECT id, nome, email, foto_perfil FROM usuarios WHERE id = ? LIMIT 1');
    $stmtUsuario->execute([$usuarioIdSessao]);
    $usuarioLogado = $stmtUsuario->fetch(PDO::FETCH_ASSOC) ?: null;

    if (!$usuarioLogado && !$isAdmin) {
        unset($_SESSION['usuario_id'], $_SESSION['usuario_nome'], $_SESSION['usuario_email'], $_SESSION['tipo_usuario']);
        $usuarioIdSessao = 0;
    }
}
$usuarioEstaLogado = (bool)$usuarioLogado;

// Buscar favoritos do usuário logado
$favoritosUsuario = [];
if ($usuarioIdSessao > 0) {
    $stmtFavs = $pdo->prepare('SELECT produto_id FROM favoritos WHERE usuario_id = ?');
    $stmtFavs->execute([$usuarioIdSessao]);
    $favoritosUsuario = array_column($stmtFavs->fetchAll(PDO::FETCH_ASSOC), 'produto_id');
}

// Adicionar produto ao carrinho
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'adicionar') {
    $produtoId = filter_input(INPUT_POST, 'produto_id', FILTER_VALIDATE_INT);

    if ($produtoId) {
        $stmt = $pdo->prepare('SELECT id, estoque FROM produtos WHERE id = ? AND ativo = 1 LIMIT 1');
        $stmt->execute([$produtoId]);
        $produtoCarrinho = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($produtoCarrinho && (int)$produtoCarrinho['estoque'] > (int)($_SESSION['carrinho'][$produtoId] ?? 0)) {
            $_SESSION['carrinho'][$produtoId] = (int)($_SESSION['carrinho'][$produtoId] ?? 0) + 1;
        }
    }

    header('Location: carrinho.php');
    exit;
}

// Buscar produtos no banco
$stmt = $pdo->query("
    SELECT id, nome, descricao, preco, estoque, categoria, imagem
    FROM produtos
    WHERE ativo = 1
    ORDER BY id DESC
");

$produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);

$quantidadeCarrinho = array_sum(array_map('intval', $_SESSION['carrinho']));

$arquivoImagens = __DIR__ . '/config/imagens-produtos.php';
$imagensProdutos = file_exists($arquivoImagens) ? require $arquivoImagens : [];

function imagemDoProduto(array $produto, array $imagens): string {
    $nome = mb_strtolower(trim((string)$produto['nome']), 'UTF-8');
    foreach ($imagens as $termo => $caminho) {
        if (mb_strpos($nome, mb_strtolower($termo, 'UTF-8')) !== false) {
            return $caminho;
        }
    }
    return trim((string)($produto['imagem'] ?? ''));
}

function imagemCategoria(array $produtos, array $termos): string {
    foreach ($produtos as $produto) {
        $texto = mb_strtolower(($produto['nome'] ?? '') . ' ' . ($produto['categoria'] ?? ''), 'UTF-8');
        foreach ($termos as $termo) {
            if (mb_strpos($texto, mb_strtolower($termo, 'UTF-8')) !== false && !empty($produto['imagem'])) {
                return (string)$produto['imagem'];
            }
        }
    }
    return '';
}

$categorias = [
    ['nome' => 'Proteínas', 'slug' => 'proteinas', 'termos' => ['proteina', 'whey'], 'icone' => '🥤', 'imagem' => 'img/proteinas.jpg'],
    ['nome' => 'Creatina', 'slug' => 'creatina', 'termos' => ['creatina'], 'icone' => '🥤', 'imagem' => 'img/creatina.jpeg'],
    ['nome' => 'Veganos', 'slug' => 'veganos', 'termos' => ['vegano', 'vegan'], 'icone' => '🌱', 'imagem' => 'img/vegan.png'],
    ['nome' => 'Termogênicos', 'slug' => 'termogenicos', 'termos' => ['termogenico', 'cafeina', 'pré-treino'], 'icone' => '🔥', 'imagem' => 'img/pre-treino.jpeg'],
    ['nome' => 'Vitaminas', 'slug' => 'vitaminas', 'termos' => ['vitamina', 'biotina'], 'icone' => '💊', 'imagem' => 'img/biotina.jpeg'],
    ['nome' => 'Acessórios', 'slug' => 'acessorios', 'termos' => ['bolsa', 'coqueteleira'], 'icone' => '👜', 'imagem' => 'img/bolsa1.jpeg'],
    ['nome' => 'Roupas', 'slug' => 'roupas', 'termos' => ['camiseta', 'bermuda'], 'icone' => '👕', 'imagem' => 'img/camisetambm.jpg'],
    ['nome' => 'Aminoácidos', 'slug' => 'aminoacidos', 'termos' => ['aminoacido', 'bcaa'], 'icone' => '⚗️', 'imagem' => 'img/bcaa.png']
];

$destaques = array_slice($produtos, 0, 4);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MBM Suplementos | Performance & Saúde</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&family=Poppins:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
:root {
    --red: #ed101b;
    --red2: #ff3039;
    --bg: #070708;
    --panel: #111113;
    --line: #29292e;
    --muted: #999;
    --white: #fff;
}
* { box-sizing: border-box; margin: 0; padding: 0; }
html { scroll-behavior: smooth; }
body { font-family: 'Poppins', sans-serif; background: var(--bg); color: var(--white); min-height: 100vh; }
a { color: inherit; text-decoration: none; }
h1, h2, h3, h4 { font-family: 'Montserrat', sans-serif; font-weight: 800; }

.site-header {
    height: 76px; background: rgba(5,5,6,.97); border-bottom: 1px solid #252529;
    position: sticky; top: 0; z-index: 50;
}
.header-inner {
    width: min(1440px,94%); height: 100%; margin: auto;
    display: flex; align-items: center; justify-content: space-between; gap: 24px;
}
.logo img { width: 150px; max-height: 58px; object-fit: contain; display: block; }
.main-nav { display: flex; align-items: center; gap: 30px; font-size: 13px; font-weight: 800; }
.main-nav a { transition: .2s; }
.main-nav a:hover { color: var(--red); }
.admin-badge { background: var(--red); color: #fff !important; padding: 7px 13px; border-radius: 6px; font-size: 11px; font-weight: 900; }

.search-form {
    display: flex; align-items: center; border: 1px solid #39393e;
    border-radius: 30px; overflow: hidden; width: min(260px,24vw); background: #0d0d0f;
}
.search-form input { width: 100%; min-width: 0; background: transparent; border: 0; outline: 0; color: white; padding: 11px 14px; font-size: 12px; }
.search-form button { background: transparent; border: 0; color: white; padding: 0 13px; cursor: pointer; font-size: 17px; }

.header-actions { display: flex; align-items: center; gap: 20px; font-size: 20px; }
.account-menu { position: relative; }
.account-trigger {
    width: 38px; height: 38px; border: 0; border-radius: 50%;
    display: grid; place-items: center; cursor: pointer;
    color: #fff; background: transparent; font-size: 21px; overflow: hidden; transition: .2s;
}
.account-trigger:hover { background: #202024; color: var(--red); }
.account-trigger img { width: 100%; height: 100%; object-fit: cover; }
.account-dropdown {
    position: absolute; top: calc(100% + 15px); right: -48px; width: 270px; padding: 12px;
    background: #111113; border: 1px solid #303035; border-radius: 12px;
    box-shadow: 0 15px 45px #000b; z-index: 100; display: none;
}
.account-menu.open .account-dropdown { display: block; }
.account-summary {
    display: flex; align-items: center; gap: 11px; padding: 8px 7px 13px;
    border-bottom: 1px solid #303035; margin-bottom: 7px; min-width: 0;
}
.account-avatar {
    width: 43px; height: 43px; flex: 0 0 43px; border-radius: 50%;
    display: grid; place-items: center; overflow: hidden; background: #29292e; color: #fff; font-weight: 800;
}
.account-avatar img { width: 100%; height: 100%; object-fit: cover; }
.account-summary strong { display:block; font-size: 13px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
.account-summary small { display:block; color:#999; font-size:10px; margin-top:3px; overflow:hidden; text-overflow:ellipsis; }
.account-dropdown a { display:flex; align-items:center; gap:10px; padding:11px 9px; border-radius:7px; color:#ddd; font-size:12px; font-weight:600; }
.account-dropdown a:hover { background:#242428; color:#fff; }
.account-dropdown a.logout-link, .account-dropdown .account-admin { color:#ff555d; }

.cart-link { position: relative; }
.cart-count {
    position: absolute; top: -9px; right: -10px; background: var(--red);
    border-radius: 50%; font-size: 10px; min-width: 18px; height: 18px;
    display: grid; place-items: center; font-weight: 900;
}

.hero { width: 100%; position: relative; overflow: hidden; background: #080808; border-bottom: 1px solid var(--line); }
.hero-image { width: 100%; height: auto; min-height: 250px; max-height: 520px; display: block; object-fit: cover; object-position: center; }
.hero-button {
    position: absolute; left: 18%; bottom: 12%; z-index: 2;
    display: inline-flex; align-items: center; gap: 12px;
    background: var(--red); color: white; padding: 15px 24px; border-radius: 8px;
    font-size: 13px; font-weight: 900; transition: .25s;
}
.hero-button:hover { background: var(--red2); transform: translateY(-3px); box-shadow: 0 8px 25px #ed101b55; }

.section { width: min(1440px,94%); margin: auto; padding: 42px 0 10px; }
.section-heading { display: flex; align-items: end; justify-content: space-between; gap: 20px; margin-bottom: 20px; }
.section-heading h2 { font-size: 28px; margin-top: 7px; }
.section-heading h2 span { color: var(--red); }
.section-kicker { color: var(--red); font-size: 12px; font-weight: 900; letter-spacing: 3px; }

.categories { display: grid; grid-template-columns: repeat(8,minmax(0,1fr)); gap: 13px; }
.category-card {
    height: 170px; position: relative; overflow: hidden; border: 1px solid #303035;
    border-radius: 13px; background: linear-gradient(145deg,#202024,#09090b);
    display: flex; align-items: center; justify-content: center; isolation: isolate; transition: .25s;
}
.category-card:before {
    content: ""; position: absolute; inset: 0;
    background: linear-gradient(0deg, rgba(0,0,0,.94), rgba(0,0,0,.05) 85%); z-index: 1;
}
.category-card:hover { border-color: var(--red); transform: translateY(-4px); }
.category-card img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain; padding: 10px; transition: .35s; }
.category-card:hover img { transform: scale(1.08); }
.category-icon { font-size: 43px; opacity: .65; }
.category-name { position: absolute; z-index: 2; left: 10px; right: 10px; bottom: 14px; text-align: center; font-size: 13px; font-weight: 700; }
.category-arrow { position: absolute; z-index: 3; right: 9px; bottom: 9px; width: 22px; height: 22px; border-radius: 50%; display: grid; place-items: center; background: var(--red); }

.featured-section { padding-top: 42px; padding-bottom: 75px; }
.see-all { font-size: 12px; font-weight: 900; border: 1px solid var(--red); border-radius: 25px; padding: 10px 16px; white-space: nowrap; transition: .2s; }
.see-all:hover { background: var(--red); }

.products-grid { display: grid; grid-template-columns: repeat(4,minmax(0,1fr)); gap: 16px; }
.product-card {
    min-width: 0; display: grid; grid-template-columns: 44% 56%; align-items: center;
    gap: 10px; padding: 14px; background: linear-gradient(145deg,#171719,#0d0d0f);
    border: 1px solid #303035; border-radius: 13px; transition: .25s;
    position: relative; cursor: pointer;
}
.product-card:hover { border-color: var(--red); transform: translateY(-4px); }

.fav-card-btn {
    position: absolute; top: 10px; right: 10px; width: 32px; height: 32px;
    border-radius: 50%; border: 1px solid #303035; background: rgba(15, 15, 18, 0.92);
    color: #fff; font-size: 16px; cursor: pointer; display: grid; place-items: center;
    z-index: 10; transition: .2s;
}
.fav-card-btn:hover { border-color: var(--red); transform: scale(1.1); }
.fav-card-btn.active { background: var(--red); border-color: var(--red); color: #fff; }

.product-image { height: 210px; display: flex; align-items: center; justify-content: center; background: radial-gradient(ellipse,#28282c,transparent 72%); min-width: 0; }
.product-image img { width: 100%; height: 100%; object-fit: contain; filter: drop-shadow(0 9px 12px #000); }
.product-info { min-width: 0; }
.product-category { font-size: 9px; color: var(--red); font-weight: 900; letter-spacing: 1.5px; text-transform: uppercase; }
.product-info h3 { font-size: 15px; line-height: 1.3; margin: 8px 0; color: #fff; font-weight: 700; }
.product-card:hover .product-info h3 { color: var(--red); }
.product-description { font-size: 10px; line-height: 1.45; color: #888; max-height: 44px; overflow: hidden; }
.product-price { font-family: 'Montserrat', sans-serif; font-size: 21px; font-weight: 900; color: var(--red); margin: 13px 0; }

.buy-btn {
    display: block; width: 100%; border: 0; border-radius: 7px; background: var(--red);
    color: white; padding: 11px 8px; font-size: 10px; font-weight: 900;
    cursor: pointer; transition: .2s; position: relative; z-index: 5;
}
.buy-btn:hover { background: var(--red2); transform: translateY(-2px); }

.empty-state { grid-column: 1/-1; padding: 35px; text-align: center; border: 1px solid var(--line); border-radius: 12px; color: #999; }

footer { border-top: 1px solid var(--line); padding: 30px 4%; text-align: center; color: #777; font-size: 12px; background: #050506; }
footer strong { color: var(--red); }

@media(max-width:1100px) {
    .categories { grid-template-columns: repeat(4,1fr); }
    .products-grid { grid-template-columns: repeat(2,1fr); }
}
@media(max-width:720px) {
    .site-header { height: auto; }
    .header-inner { padding: 13px 0; flex-wrap: wrap; }
    .logo img { width: 115px; }
    .main-nav { order: 3; width: 100%; justify-content: center; gap: 24px; }
    .search-form { width: 42vw; }
    .hero-image { min-height: 190px; max-height: none; }
    .hero-button { left: 7%; bottom: 8%; padding: 10px 13px; font-size: 10px; }
    .categories { grid-template-columns: repeat(2,1fr); }
    .products-grid { grid-template-columns: 1fr; }
}
</style>
</head>
<body>

<header class="site-header">
    <div class="header-inner">
        <a class="logo" href="loja.php">
            <img src="img/mbm logo sem fundo.png" alt="MBM Suplementos">
        </a>

        <nav class="main-nav">
            <a href="loja.php">Início</a>
            <a href="produtos.php">Produtos</a>
            <a href="favoritar/favoritos.php">Favoritos</a>
            <a href="#sobre">Sobre nós</a>
            <a href="#contato">Contato</a>
            <?php if ($isAdmin): ?>
                <a class="admin-badge" href="admin.php">PAINEL ADMIN</a>
            <?php endif; ?>
        </nav>

        <form class="search-form" action="produtos.php" method="get">
            <input type="search" name="busca" placeholder="Buscar produtos..." aria-label="Buscar produtos">
            <button type="submit" aria-label="Buscar">⌕</button>
        </form>

        <div class="header-actions">
            <div class="account-menu" id="accountMenu">
                <?php if ($usuarioEstaLogado): ?>
                    <button class="account-trigger" id="accountTrigger" type="button" aria-label="Abrir menu da conta" aria-expanded="false">
                        <?php if (!empty($usuarioLogado['foto_perfil'])): ?>
                            <img src="<?= e($usuarioLogado['foto_perfil']) ?>" alt="Foto de perfil">
                        <?php else: ?>
                            👤
                        <?php endif; ?>
                    </button>
                    <div class="account-dropdown">
                        <div class="account-summary">
                            <div class="account-avatar">
                                <?php if (!empty($usuarioLogado['foto_perfil'])): ?>
                                    <img src="<?= e($usuarioLogado['foto_perfil']) ?>" alt="">
                                <?php else: ?>
                                    <?= e(mb_strtoupper(mb_substr($usuarioLogado['nome'], 0, 1, 'UTF-8'), 'UTF-8')) ?>
                                <?php endif; ?>
                            </div>
                            <div style="min-width:0">
                                <strong><?= e($usuarioLogado['nome']) ?></strong>
                                <small><?= e($usuarioLogado['email']) ?></small>
                            </div>
                        </div>
                        <a href="conta.php">👤 Minha conta</a>
                        <a href="meus-pedidos.php">📦 Meus pedidos</a>
                        <a href="favoritar/favoritos.php">♥ Meus favoritos</a>
                        <?php if ($isAdmin): ?>
                            <a class="account-admin" href="admin.php">⚙ Painel administrativo</a>
                        <?php endif; ?>
                        <a class="logout-link" href="sair.php">↪ Sair da conta</a>
                    </div>
                <?php else: ?>
                    <a class="account-trigger" href="index.php?modo=login" aria-label="Entrar na conta" title="Entrar na conta">👤</a>
                <?php endif; ?>
            </div>

            <a class="cart-link" href="carrinho.php" aria-label="Carrinho">
                🛒
                <?php if ($quantidadeCarrinho > 0): ?>
                    <span class="cart-count"><?= $quantidadeCarrinho ?></span>
                <?php endif; ?>
            </a>
        </div>
    </div>
</header>

<main>
<section class="hero">
    <img class="hero-image" src="img/banner-mbm.jpg" alt="MBM Suplementos - Suplemente e evolua">
    <a class="hero-button" href="produtos.php">🛒 VER PRODUTOS <span>→</span></a>
</section>

<section class="section">
    <div class="section-heading">
        <div>
            <div class="section-kicker">EXPLORE NOSSA LINHA</div>
            <h2>Categorias <span>MBM</span></h2>
        </div>
    </div>

    <div class="categories">
        <?php foreach ($categorias as $categoria): ?>
            <?php $img = $categoria['imagem'] ?? imagemCategoria($produtos, $categoria['termos']); ?>
            <a class="category-card" href="produtos.php?categoria=<?= e($categoria['slug']) ?>">
                <?php if ($img !== ''): ?>
                    <img src="<?= e($img) ?>" alt="<?= e($categoria['nome']) ?>" loading="lazy">
                <?php else: ?>
                    <span class="category-icon"><?= e($categoria['icone']) ?></span>
                <?php endif; ?>
                <span class="category-name"><?= e($categoria['nome']) ?></span>
                <span class="category-arrow">›</span>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<section class="section featured-section" id="destaques">
    <div class="section-heading">
        <div>
            <div class="section-kicker">ESCOLHAS PARA SUA EVOLUÇÃO</div>
            <h2>Produtos em <span>destaque</span></h2>
        </div>
        <a class="see-all" href="produtos.php">Ver todos os produtos →</a>
    </div>

    <div class="products-grid">
        <?php if (!$destaques): ?>
            <div class="empty-state">
                Ainda não há produtos ativos cadastrados. Adicione produtos pelo painel administrativo.
            </div>
        <?php endif; ?>

        <?php foreach ($destaques as $produto): ?>
            <?php
            $img = imagemDoProduto($produto, $imagensProdutos);
            $isFav = in_array($produto['id'], $favoritosUsuario);
            $linkProduto = 'produtos.php?id=' . (int)$produto['id'];
            ?>

            <article class="product-card" onclick="window.location.href='<?= $linkProduto ?>'">
                <button type="button"
                        class="fav-card-btn <?= $isFav ? 'active' : '' ?>"
                        onclick="event.stopPropagation(); toggleFavorito(<?= (int)$produto['id'] ?>, this)"
                        title="<?= $isFav ? 'Remover dos favoritos' : 'Adicionar aos favoritos' ?>">
                    <?= $isFav ? '♥' : '♡' ?>
                </button>

                <div class="product-image">
                    <?php if ($img !== ''): ?>
                        <img src="<?= e($img) ?>" alt="<?= e($produto['nome']) ?>" loading="lazy">
                    <?php else: ?>
                        <span class="category-icon">🥤</span>
                    <?php endif; ?>
                </div>

                <div class="product-info">
                    <div class="product-category"><?= e($produto['categoria'] ?? 'Suplemento') ?></div>
                    <h3><a href="<?= $linkProduto ?>"><?= e($produto['nome']) ?></a></h3>
                    <p class="product-description"><?= e($produto['descricao'] ?? '') ?></p>
                    <div class="product-price">R$ <?= number_format((float)$produto['preco'], 2, ',', '.') ?></div>

                    <form method="post" onclick="event.stopPropagation()">
                        <input type="hidden" name="acao" value="adicionar">
                        <input type="hidden" name="produto_id" value="<?= (int)$produto['id'] ?>">
                        <button class="buy-btn" type="submit">🛒 ADICIONAR AO CARRINHO</button>
                    </form>
                </div>
            </article>
        <?php endforeach; ?>
    </div>
</section>
</main>

<footer id="contato">
    <strong>MBM SUPLEMENTOS</strong>
    <p>Performance • Força • Resultado</p>
    <p>© <?= date('Y') ?> MBM Suplementos. Todos os direitos reservados.</p>
</footer>

<script>
function toggleFavorito(produtoId, btn) {
    const formData = new FormData();
    formData.append('produto_id', produtoId);

    fetch('favoritar/favoritar.php', {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === 'nao_logado') {
            window.location.href = data.redirect;
        } else if (data.status === 'ok') {
            btn.classList.toggle('active', data.favoritado);
            btn.textContent = data.favoritado ? '♥' : '♡';
        }
    });
}

(function () {
    const menu = document.getElementById('accountMenu');
    const trigger = document.getElementById('accountTrigger');
    if (!menu || !trigger) return;
    trigger.addEventListener('click', function (event) {
        event.stopPropagation();
        const aberto = menu.classList.toggle('open');
        trigger.setAttribute('aria-expanded', aberto ? 'true' : 'false');
    });
    document.addEventListener('click', function (event) {
        if (!menu.contains(event.target)) {
            menu.classList.remove('open');
            trigger.setAttribute('aria-expanded', 'false');
        }
    });
})();
</script>
</body>
</html>