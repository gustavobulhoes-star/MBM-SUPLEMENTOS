<?php

declare(strict_types=1);

session_start();
require_once __DIR__ . '/config/database.php';

if (empty($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

$pedidoId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$pedidoId) {
    header('Location: pedidos.php');
    exit;
}

$consulta = $pdo->prepare(
    'SELECT id, total, status, pagamento, criado_em
     FROM pedidos
     WHERE id = :id AND usuario_id = :usuario_id'
);

$consulta->execute([
    ':id' => $pedidoId,
    ':usuario_id' => (int) $_SESSION['usuario_id']
]);

$pedido = $consulta->fetch();

if (!$pedido) {
    http_response_code(404);
    exit('Pedido não encontrado.');
}

$nomesPagamento = [
    'pix' => 'PIX',
    'cartao' => 'Cartão',
    'boleto' => 'Boleto'
];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >
    <title>Pedido confirmado - MBM Suplementos</title>
    <link rel="stylesheet" href="css/finalizar.css">
    <style>
        .confirmacao {
            width: min(600px, calc(100% - 30px));
            margin: 80px auto;
            padding: 38px;
            border: 1px solid #303036;
            border-radius: 16px;
            background: #18181b;
            text-align: center;
        }

        .icone {
            width: 72px;
            height: 72px;
            margin: 0 auto 20px;
            border-radius: 50%;
            color: #08150f;
            background: #42d392;
            font-size: 36px;
            font-weight: bold;
            display: grid;
            place-items: center;
        }

        .confirmacao h1 {
            margin-bottom: 10px;
        }

        .confirmacao p {
            color: #a7a7b0;
        }

        .dados {
            margin: 26px 0;
            padding: 20px;
            border-radius: 10px;
            background: #111114;
            text-align: left;
        }

        .dados div {
            padding: 8px 0;
            display: flex;
            justify-content: space-between;
        }

        .inicio {
            display: inline-block;
            padding: 14px 22px;
            border-radius: 8px;
            color: white;
            background: #ff2f39;
            font-weight: bold;
            text-decoration: none;
        }
    </style>
</head>
<body>
<main class="confirmacao">
    <div class="icone">✓</div>

    <h1>Pedido realizado!</h1>

    <p>
        Seu pedido foi registrado e está aguardando o pagamento.
    </p>

    <div class="dados">
        <div>
            <span>Número</span>
            <strong>#<?= (int) $pedido['id'] ?></strong>
        </div>

        <div>
            <span>Pagamento</span>
            <strong>
                <?= htmlspecialchars(
                    $nomesPagamento[$pedido['pagamento']]
                    ?? $pedido['pagamento']
                ) ?>
            </strong>
        </div>

        <div>
            <span>Status</span>
            <strong><?= htmlspecialchars($pedido['status']) ?></strong>
        </div>

        <div>
            <span>Total</span>
            <strong>
                R$ <?= number_format(
                    (float) $pedido['total'],
                    2,
                    ',',
                    '.'
                ) ?>
            </strong>
        </div>
    </div>

    <a class="inicio" href="index.php">VOLTAR À LOJA</a>
</main>
</body>
</html>
