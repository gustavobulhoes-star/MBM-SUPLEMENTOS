
<?php
session_start();


if (isset($_SESSION['admin_id'])) {
    header('Location: admin/index.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Acesso Administrativo | MBM</title>

<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    background: #090909;
    color: white;
    font-family: Arial, sans-serif;
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 20px;
}

.container {
    width: 100%;
    max-width: 480px;
    background: #171717;
    border: 1px solid #333;
    border-radius: 15px;
    padding: 40px 30px;
    text-align: center;
}

.logo {
    font-size: 38px;
    font-weight: 900;
    font-style: italic;
    margin-bottom: 30px;
}

.logo span {
    color: #ed2027;
}

h1 {
    font-size: 26px;
    margin-bottom: 12px;
}

p {
    color: #aaa;
    line-height: 1.6;
    margin-bottom: 30px;
}

a {
    display: block;
    text-decoration: none;
    padding: 16px;
    border-radius: 7px;
    margin-top: 15px;
    font-weight: bold;
    transition: .3s;
}

.login {
    background: #ed2027;
    color: white;
}

.login:hover {
    background: #bd1017;
}

.cadastro {
    background: #292929;
    color: white;
    border: 1px solid #444;
}

.cadastro:hover {
    border-color: #ed2027;
}

.voltar {
    color: #aaa;
    font-size: 13px;
    margin-top: 25px;
}
</style>
</head>

<body>

<div class="container">

    <div class="logo">MBM<span>.</span></div>

    <h1>ÁREA ADMINISTRATIVA</h1>

    <p>
        Entre na sua conta administrativa
        ou cadastre o primeiro administrador da loja.
    </p>

    <a href="login.php" class="login">
        ENTRAR COMO ADMINISTRADOR →
    </a>

    <a href="criar_admin.php" class="cadastro">
        CRIAR ADMINISTRADOR
    </a>

    <a href="index.php" class="voltar">
        ← VOLTAR À PÁGINA INICIAL
    </a>

</div>

</body>
</html>
